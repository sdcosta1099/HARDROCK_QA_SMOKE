$(document).click(function (e) {
    if ($(e.target).parents(".popup-box").length === 0) {
        $(".popup-box").hide();
    }
});

function ShowSummary() {
    HideLoader();
    $('#mask').hide();
    $('.window').hide();
    ShowPopDialog('#dvMasterItemSummary');
}

function ShowLoader() {

    var mask = $('#maskLocal');

    //Get the screen height and width
    var maskHeight = $(document).height();
    var maskWidth = $(document).width();

    //Set heigth and width to mask to fill up the whole screen
    $(mask).css({ 'width': maskWidth, 'height': maskHeight });

    //transition effect		
    $(mask).fadeIn(250);
    $(mask).fadeTo("slow", 0.5);

    $("#dvProgressLocal").show();
}



// for start time validation
$('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningStartTime').blur(function () {

    var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningStartTime').val();
    if (validateTime(txtTime) || txtTime.length == 0) {
        return true;
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningStartTime').val('');
        SuccessMessage('Start Time is invalid');
        return false;
    }
});


// for end time validation
$('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningEndTime').blur(function () {
    var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningEndTime').val();
    if (validateTime(txtTime) || txtTime.length == 0) {
        return true;
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningEndTime').val('');
        SuccessMessage('End Time is invalid');
        return false;
    }
});





function SetPrizeAttributeID(PrizeAttributeID, TotalBooked) {
    ShowLoader();
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnPrizeAttributeID').val(PrizeAttributeID);
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnTotalBooked').val(TotalBooked);
}

function HideLoader() {
    $('#maskLocal').hide();
    $("#dvProgressLocal").hide();
  
}

function IsInventoryValid(evt) {
    var regex = new RegExp("^[0-9-]+$");
    var str = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
    if (!regex.test(str)) {
        return false;
    }
}

function ValidateItemAttribute() {
    var inventory = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPhysicalInventory').val();
    if (parseInt(inventory) <= 0 || isNaN(parseInt(inventory))) {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPhysicalInventory').val("");
        return false;
    }
}

function ValidatePrize() {
    var inventory = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPrizePhyInventory').val();
    if (parseInt(inventory) <= 0 || isNaN(parseInt(inventory))) {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPrizePhyInventory').val("");
        //Code comented as part of ticket 20228
        //$('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtNoShow').val("0");
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtBookingLimit').val("");
        return false;
    }
}

function IsNoShowValid(evt) {
    var regex = new RegExp("^[0-9-]+$");
    var str = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
    if (!regex.test(str)) {
        return false;
    }

}

function CalculateBookingLimit() {
    var inventory = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPrizePhyInventory').val();
    var noShowPerc = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtNoShow').val();
    if (inventory != "" && noShowPerc != "") {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtBookingLimit').val(Math.round(parseInt(inventory) / (1 - noShowPerc / 100)));
    }
}

function initDropDown(sender, args) {
    $(sender.get_element()).find('input.igdd_ValueDisplay').on('focus', function () {
        this.blur();
    });
}

function SetOfferLocationID(OfferMasterItemID) {
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnOfferMasterItemID').val(OfferMasterItemID);
}
function SetOfferLocationIDAndTotalBooked(OfferMasterItemID, TotalBooked) {
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnOfferMasterItemID').val(OfferMasterItemID);
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnTotalBooked').val(TotalBooked);
}

function callUpdateDeletePopup(param, e, status) {
    $(".popup-box").hide();
    $(param).next().show();
    $(".popup-option-copy").show();

    e.stopPropagation();
}

function BindAutoComplete() {
    $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtCmpPrizeCode").devbridgeAutocomplete({
        minChars: 5,
        lookup: function (query, done) {
            $.ajax({
                url: "ManageEventAndOfferPage.aspx/GetAutoCompleteData",
                data: "{ 'SearchText':'" + query + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {

                    var result = []

                    for (var i = 0; i < data.d.length; i++) {

                        result.push({ value: data.d[i], data: data.d[i] });
                    }

                    var Suggest = {
                        suggestions:
                            result
                    };


                    done(Suggest);

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {

                }
            });
        },
        onSelect: function (suggestion) {

        }
    });
}

function doc_keyUp(e) {
    document.getElementById("ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtUnitCost").value = document.getElementById("ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtUnitCost").value.replace("$", "");

    if (document.getElementById("ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtUnitCost").value != '') {
        document.getElementById("ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtUnitCost").value = "$" + document.getElementById("ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtUnitCost").value ;
    }
}

function IsDecimal(txt, event) {
    var charCode = (event.which) ? event.which : event.keyCode

    if (charCode == '8') {
        return true;
    }
    if (charCode == 46) {
        if (txt.value.indexOf(".") < 0)
            return true;
        else
            return false;
    }

    if (txt.value.indexOf(".") > 0) {
        var txtlen = txt.value.length;
        var dotpos = txt.value.indexOf(".");
        if ((txtlen - dotpos) > 2)
            return false;
    }

    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}

$(document).ready(function () {
    bindControlML();
    BindAutoComplete();
    $('.calendar.igmc_Control').click(function (evt) {
        evt.stopPropagation();
    })
    $(document).click(function () {
        $('.calendar.igmc_Control').css("display", 'none');
        $('.calendar.igmc_Control').click(function (evt) {
            evt.stopPropagation();
        })
    });

    document.addEventListener('keyup', doc_keyUp, false);
    document.addEventListener('keyup', noShowCostDocKeyUp, false);
})

function setStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_StartDate').css("display", 'none');
}

function setEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_EndDate').css("display", 'none');
}

function SetEarningStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningStartDate').css("display", 'none');
}

function SetEarningEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEarningEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningEndDate').css("display", 'none');
}


function AskConfirmation1(fillFor, evt) {
    $('.calendar.igmc_Control').click(function (evt) {
        evt.stopPropagation();
    })
    evt.stopPropagation();
    switch (fillFor) {
        case 1:
            if ($('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_StartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_StartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_StartDate').css("display", 'block');
            }
            break;
        case 2:
            if ($('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_EndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_EndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_CalendarViewmaster_EndDate').css("display", 'block');
            }
            break;
        default:
            break;
    }
}

function AskEarningConfirmation(fillFor, evt) {
    $('.calendar.igmc_Control').click(function (evt) {
        evt.stopPropagation();
    })
    evt.stopPropagation();
    switch (fillFor) {
        case 1:
            if ($('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningStartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningStartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningStartDate').css("display", 'block');
            }
            break;
        case 2:
            if ($('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningEndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningEndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_WebMonthCalendar_EarningEndDate').css("display", 'block');
            }
            break;
        default:
            break;
    }
}

function bindControlML() {
    // initialize input widgets first
    $('#ESbasicEarningScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#ESbasicEarningScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#MLbasicScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#MLbasicScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_dateSection .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_dateSection .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    //$('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtStartDate').datepicker();
    //$('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndDate').datepicker();
    $(document).on('click', '#txtStartDate', function () {
        $(this).datepicker().on('changeDate', dateChangedStartDate);


    });

    //$(document).on('click', '#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndDate', function () {
    //    $(this).datepicker().on('changeDate', dateChangedendDate);

    //});


    $(".time.start").each(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.start").change(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.end").each(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.end").change(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    // for start time validation
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtStarttime').blur(function () {

        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtStarttime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtStarttime').val('');
            SuccessMessage('Start Time is invalid');
            return false;
        }
    });

    // for end time validation
    $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndtime').blur(function () {
        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndtime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtEndtime').val('');
            SuccessMessage('End Time is invalid');
            return false;
        }
    });
}
function validateTime(sTime) {
    var filter = /^([0]?[1-9]|1[0-2]):([0-5]\d)\s?(AM|PM)$/i;
    if (filter.test(sTime)) {
        return true;
    }
    else {
        return false;
    }
}


function scrollTop() {
    setTimeout(function () {
        $(window).scrollTop(0);
    }, 100);
    $('html').css('overflow-y', 'hidden');
    if ($('#head2').css("overflow-y", "scroll")) {

        // Get the current page scroll position
        scrollTop1 = window.pageYOffset || document.documentElement.scrollTop1;
        scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,

            // if any scroll is attempted, set this to the previous value
            window.onscroll = function () {
                window.scrollTo(scrollLeft, scrollTop1);
            };
    }
}
function showScroll() {
    $('html').css('overflow-y', 'scroll');
}