$(document).click(function (e) {
    if ($(e.target).parents(".popup-box").length === 0) {
        $(".popup-box").hide();
    }
});

function initDropDown(sender, args) {
    $(sender.get_element()).find('input.igdd_ValueDisplay').on('focus', function () {
        this.blur();
    });
}

function SetOfferSegmentID(OfferSegmentID) {
    ShowLoader();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_hdnSegmentID').val(OfferSegmentID);
}

function HideLoader() {
    $('#maskLocal').hide();
    $("#ctl00_ContentPlaceHolder1_ctrlSegments_dvProgressLocal").hide();
}

function callUpdateDeletePopup(param, e) {
    $(".popup-box").hide();
    $(param).next().show();
    $(".popup-option-copy").show();
    e.stopPropagation();
}

function ShowLoader() {

    var mask = $('#maskLocal');

    //Get the screen height and width
    var maskHeight = $(document).height();
    var maskWidth = $(document).width();

    //Set heigth and width to mask to fill up the whole screen
    $(mask).css({ 'width': maskWidth, 'height': maskHeight });

    //transition effect		
    $(mask).fadeIn(250);
    $(mask).fadeTo("slow", 0.5);

    $("#ctl00_ContentPlaceHolder1_ctrlSegments_dvProgressLocal").show();
}

function SegmentSetStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_StartDate').css("display", 'none');
}

function SegmentSetEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_EndDate').css("display", 'none');
}

function setDisplayStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtDisplayStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtDisplayStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayStartDate').css("display", 'none');
}

function setDisplayEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtDisplayEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtDisplayEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayEndDate').css("display", 'none');
}

function setBookStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtBookStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtBookStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookStartDate').css("display", 'none');
}

function setBookEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtBookEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtBookEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookEndDate').css("display", 'none');
}

function noShowCostDocKeyUp(e) {
    document.getElementById("ctl00_ContentPlaceHolder1_ctrlSegments_NoShowCost").value = document.getElementById("ctl00_ContentPlaceHolder1_ctrlSegments_NoShowCost").value.replace("$", "");

    if (document.getElementById("ctl00_ContentPlaceHolder1_ctrlSegments_NoShowCost").value != '') {
        document.getElementById("ctl00_ContentPlaceHolder1_ctrlSegments_NoShowCost").value = "$" + document.getElementById("ctl00_ContentPlaceHolder1_ctrlSegments_NoShowCost").value;
    }
}

function AskConfirmationSegment(fillFor, evt) {
    $('.calendar.igmc_Control').click(function (evt) {
        evt.stopPropagation();
    })
    evt.stopPropagation();
    switch (fillFor) {
        case 1:
            if ($('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_StartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_StartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_StartDate').css("display", 'block');
            }
            break;
        case 2:
            if ($('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_EndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_EndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_EndDate').css("display", 'block');
            }
            break;
        case 3:
            if ($('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayStartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayStartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayStartDate').css("display", 'block');
            }
            break;
        case 4:
            if ($('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayEndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayEndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_DisplayEndDate').css("display", 'block');
            }
            break;
        case 5:
            if ($('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookStartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookStartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookStartDate').css("display", 'block');
            }
            break;
        case 6:
            if ($('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookEndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookEndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlSegments_CalendarViewmaster_BookEndDate').css("display", 'block');
            }
            break;
        default:
            break;
    }
}

//$(document).delegate('.dateFormatExt', 'keydown', function (e) {
//    // Allow: backspace, delete, tab, escape, enter and .
//    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
//        // Allow: Ctrl+A, Command+A
//        (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
//        // Allow: home, end, left, right, down, up
//        (e.keyCode >= 35 && e.keyCode <= 40)) {
//        // let it happen, don't do anything
//        return;
//    }
//    // Ensure that it is a number and stop the keypress
//    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
//        e.preventDefault();
//    }
//    if (e.keyCode === 47) {
//        return false;
//    }
//});

//$(document).delegate('.dateFormatExt', 'keyup', function (e) {
//    if (e.which === 8 || e.which === 127) {
//    } else if (this.value.length === 2 || this.value.length === 5) {
//        this.value += "/";
//    }
//});

//function dateChangedStartDate(ev) {
//    $(this).datepicker('hide');
//    if (ev.date != undefined) {
//        var date = ev.date.toString();
//        var year = date.slice(-4),
//            month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].indexOf(date.substr(4, 3)) + 1,
//            day = date.substr(8, 2);

//        if (year == 'ime)') {
//            year = date.substr(11, 4)
//        }
//        var output = month + '/' + day + '/' + year;
//        $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtStartDate").val(output);
//        CompareDatesStartNew();
//    }
//}

//function dateChangedendDate(ev) {
//    $(this).datepicker('hide');
//    if (ev.date != undefined) {
//        var date = ev.date.toString();
//        var year = date.slice(-4),
//            month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].indexOf(date.substr(4, 3)) + 1,
//            day = date.substr(8, 2);

//        if (year == 'ime)') {
//            year = date.substr(11, 4)
//        }
//        var output = month + '/' + day + '/' + year;
//        $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate").val(output);
//        CompareDatesEnd();
//    }
//}

//function CompareDatesEnd() {
//    var dateStart = $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtStartDate").val();
//    var endDate = $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate").val();

//    var dateFirst = dateStart.split('/')
//    var dateSecond = endDate.split('/')
//    var value = new Date(dateFirst[2], dateFirst[0], dateFirst[1]); //Year, Month, Date
//    var current = new Date(dateSecond[2], dateSecond[0], dateSecond[1]);
//    if (current < value) {
//        SuccessMessage('End date cannot be less than Start Date');
//        $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate").val("");
//    }
//}

function isNumberKey(evt) {
    var regex = new RegExp("^[0-9-]+$");
    var str = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
    if (!regex.test(str)) {
        return false;
    }
}

//function CompareDatesStartNew() {
//    var dateStart = $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtStartDate").val();
//    var endDate = $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate").val();
//    var dateFirst = dateStart.split('/')
//    var dateSecond = endDate.split('/')
//    var value = new Date(dateFirst[2], dateFirst[0], dateFirst[1]); //Year, Month, Date
//    var current = new Date(dateSecond[2], dateSecond[0], dateSecond[1]);
//    if (current < value) {
//        $("#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate").val(dateStart);
//    }
//}

function bindControl() {
    $('#basicScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#basicScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#basicDisplayScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#basicDisplayScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#basicBookScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#basicBookScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#ctl00_ContentPlaceHolder1_ctrlSegments_dateSection .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#ctl00_ContentPlaceHolder1_ctrlSegments_dateSection .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    //$('#ctl00_ContentPlaceHolder1_ctrlSegments_txtStartDate').datepicker();
    //$('#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate').datepicker();
    $(document).on('click', '#txtStartDate', function () {
        $(this).datepicker().on('changeDate', dateChangedStartDate);


    });

    //$(document).on('click', '#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndDate', function () {
    //    $(this).datepicker().on('changeDate', dateChangedendDate);

    //});


    $(".time.start").each(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.start").change(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.end").each(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.end").change(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    // for start time validation
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtStarttime').blur(function () {

        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtStarttime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtStarttime').val('');
            SuccessMessage('Start Time is invalid');
            return false;
        }
    });

    // for end time validation
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndtime').blur(function () {
        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndtime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtEndtime').val('');
            SuccessMessage('End Time is invalid');
            return false;
        }
    });
}
$(document).ready(function () {
    bindControl();
    $('.calendar.igmc_Control').click(function (evt) {
        evt.stopPropagation();
    })
    $(document).click(function () {
        $('.calendar.igmc_Control').css("display", 'none');
        $('.calendar.igmc_Control').click(function (evt) {
            evt.stopPropagation();
        })
    });
});
function validateTime(sTime) {
    var filter = /^([0]?[1-9]|1[0-2]):([0-5]\d)\s?(AM|PM)$/i;
    if (filter.test(sTime)) {
        return true;
    }
    else {
        return false;
    }
}

function EnableMaxAttendControl() {
    if ($("#ctl00_ContentPlaceHolder1_ctrlSegments_rdYes").prop("checked")) {
        $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtMaxAttendees').prop("disabled", false);
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtMaxAttendees').prop("disabled", true);
    }
    $('#ctl00_ContentPlaceHolder1_ctrlSegments_txtMaxAttendees').val("0");
}

