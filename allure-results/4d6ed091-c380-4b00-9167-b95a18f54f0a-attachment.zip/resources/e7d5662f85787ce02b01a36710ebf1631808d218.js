//Genric Functions
var CTAPhoneNumberValue = '';

function ShowProgress(id) {
    ShowPopDialog(id);
}
function HideProgress() {
    $('#ctl00_ContentPlaceHolder1_imgLoader').hide();
    DismissPop();
}

function ShowPopDialog(id) {
    //Get the screen height and width
    var maskHeight = $(document).height();
    var maskWidth = $(window).width();

    //Set heigth and width to mask to fill up the whole screen
    $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

    //transition effect		
    $('#mask').fadeIn(1000);
    $('#mask').fadeTo("slow", 0.5);

    //Get the window height and width
    var winH = $(window).height();
    var winW = $(window).width();

    //Set the popup window to center
    $(id).css('top', (winH + 90) / 2 - $(id).height());
    $(id).css('left', winW / 2 - $(id).width() / 2);

    //transition effect
    $(id).fadeIn(2000);

    //when window re-sized keep the popup window to center
    $(window).resize(function () {
        //get window width
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
    });
}

function DismissPop() {
    $('#mask').hide();
    $('.window').hide();
    $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").show();
    $('html').css('overflow-y', 'scroll');
    if ($('#head2').css("overflow-y", "scroll")) {
        window.onscroll = function () { };
    }
}

function DismissPopDeleteFile() {
    $('#mask').hide();
    $('.window').hide();
}

function ClosePopDeleteFile() {
    $('#mask').hide();
    $('.window').hide();
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDelete').prop("disabled", false);
}

//OfferSetup
function AppendOfferIDToURL(offerMasterID) {
    var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?OfferMasterID=' + offerMasterID + '';
    window.history.pushState({ path: newurl }, '', newurl);
}
function RefreshOfferCreation() {
    location.reload();
}
function isNumberKey(evt) {
    var regex = new RegExp("^[0-9-]+$");
    var str = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
    if (!regex.test(str)) {
        return false;
    }
}

function updateDates(sender, e) {

    var DisplayEndDate = "";
    var str = $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_wneDaysPrior_clientState').val().replace("|0|01", "").replace("||", "");
    if (str == "") {
        var editor = sender;
        editor.set_value("0");
        str = 0;
    }
    var displayOldEndDate = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val())
    if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetuptxtStartDate').val() != "") {
        var date = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate').val()) //17432
        date = new Date(date.format("MM/dd/yyyy"));
        //var endDate = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').val())
        date.setDate(date.getDate() - str);
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').val(date.format("MM/dd/yyyy"));
        //endDate = date.setDate(date.getDate() + str);
        DisplayEndDate = new Date(date.format("MM/dd/yyyy"));
        var cal = $find('ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate');
        cal.set_selectedDate(DisplayEndDate);
    }
    if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').val() != "") {
        var endDate = DisplayEndDate;
        endDate.setDate(endDate.getDate() + eval(str));
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val(endDate.format("MM/dd/yyyy"));
        var cal = $find('ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate');
        cal.set_selectedDate(DisplayEndDate);

    }
    if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val() != "") {
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val(displayOldEndDate.format("MM/dd/yyyy"));
        var cal = $find('ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate');
        cal.set_selectedDate(displayOldEndDate);
    }

}

function updateDisplayDate(evt, e) {
    updateDates(evt, e);
}

function updateKioskDates(sender, e) {

    var DisplayEndDate = "";
    var str = $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_wneDaysPrior_clientState').val().replace("|0|01", "").replace("||", "");
    
    if (str == "") {
        var editor = sender;
        editor.set_value("0");
        str = 0;
    }

    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_hdnDaysPrior').val(str)
    var displayOldEndDate = new Date($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val())
    if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayStartDate').val() != "") {
        var date = new Date($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_hdnStarDate').val()) //17432
        date = new Date(date.format("MM/dd/yyyy"));
        //var endDate = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').val())
        date.setDate(date.getDate() - str);
        $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayStartDate').val(date.format("MM/dd/yyyy"));
        //endDate = date.setDate(date.getDate() + str);
        DisplayEndDate = new Date(date.format("MM/dd/yyyy"));
        var cal = $find('ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayStartDate');
        cal.set_selectedDate(DisplayEndDate);
    }
    if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val() != "") {
        var endDate = DisplayEndDate;
        endDate.setDate(endDate.getDate() + eval(str));
        $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val(endDate.format("MM/dd/yyyy"));
        var cal = $find('ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate');
        cal.set_selectedDate(DisplayEndDate);

    }
    if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val() != "") {
        $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val(displayOldEndDate.format("MM/dd/yyyy"));
        var cal = $find('ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate');
        cal.set_selectedDate(displayOldEndDate);
    }

}


function updateDisplayDates(evt, e) {
    updateKioskDates(evt, e);
}


function UpdateNumberOfDays() {
    var date1 = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').val());
    var date2 = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val());
    //var diffDays = (date2.getTime() - date1.getTime()) / (1000 * 3600 * 24)
    //$(".igte_EditInContainer")[0].value = diffDays;
    if (date1 > date2 || date2 < date1) {
        diffDays = 0;
    }
    else {
        diffDays = (date2.getTime() - date1.getTime()) / (1000 * 3600 * 24);
    }
    $(".igte_EditInContainer")[0].value = Math.round(diffDays);
}

function AllowAlphaNumberic(e) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
        return true;
    }
    var charCode = (e.which) ? e.which : e.keyCode;
    if (charCode == 32 || charCode == 13) {
        return true;
    }

    e.preventDefault();
    return false;
}
function AllowDecimal(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;

    return true;
}

function RestoreCTAPhoneNumber() {
    var str = $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTAPhoneNumber').val();

    if (str === '') {
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTAPhoneNumber').val(CTAPhoneNumberValue);

        var displayDesc = 'Call Customer Care at ' + CTAPhoneNumberValue + ' and enter your seminole Wild Card number for personalized service.';
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTADescription').val(displayDesc);
    }
}

function ClearCTAPhoneNumber() {
    CTAPhoneNumberValue = $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTAPhoneNumber').val();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTAPhoneNumber').val('');
}

function UpdateCTADescription(evt) {

    var str = $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTAPhoneNumber').val()
    var displayDesc = 'Call Customer Care at ' + str + ' and enter your seminole Wild Card number for personalized service.';
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtCTADescription').val(displayDesc)
}

function initDropDown(sender, args) {
    sender.closeDropDown();
}
function OfferSetupSetStartDate(sender, args) {

    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_EndDate').css("display", 'none');

    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_wneDaysPrior_clientState').val($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_hdnDaysPrior').val())
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_StartDate').css("display", 'none');

    var str = $(".igte_EditInContainer")[0].value;
    var date = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate').val());
    date = new Date(date.format("MM/dd/yyyy"));
    date.setDate(date.getDate() - str);
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').val(date.format("MM/dd/yyyy"));
}

function OfferSetupSetBookStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookStartDate').css("display", 'none');
}

function OfferSetupSetBookEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookEndDate').css("display", 'none');
}

function OfferSetupSetDisplayStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate').css("display", 'none');
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookStartDate').css("display", 'none');

    var date1 = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').val());
    var date2 = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val());
    var diffDays = 0;
    if (date1 > date2 || date2 < date1) {
        diffDays = 0;
    }
    else {
        diffDays = (date2.getTime() - date1.getTime()) / (1000 * 3600 * 24);
    }
    $(".igte_EditInContainer")[0].value = Math.round(diffDays);

}

function KioskSetDisplayStartDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate').css("display", 'none');
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtBookStartDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtBookStartDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_BookStartDate').css("display", 'none');

    var date1 = new Date($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayStartDate').val());
    var date2 = new Date($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val());
    var diffDays = 0;
    if (date1 > date2 || date2 < date1) {
        diffDays = 0;
    }
    else {
        diffDays = (date2.getTime() - date1.getTime()) / (1000 * 3600 * 24);
    }
    $(".igte_EditInContainer")[0].value = Math.round(diffDays);
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_hdnDaysPrior').val(Math.round(diffDays));
}

function OfferSetupSetDisplayEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate').css("display", 'none');
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtBookEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookEndDate').css("display", 'none');
    //var date1 = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayStartDate').val());
    //var date2 = new Date($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val());
    //var diffDays = 0;
    //if (date2 < date1) {
    //    diffDays = 0;
    //}
    //else {
    //    diffDays = (date2.getTime() - date1.getTime()) / (1000 * 3600 * 24);
    //}
    //$(".igte_EditInContainer")[0].value = Math.round(diffDays);
}

function KioskSetDisplayEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate').css("display", 'none');
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtBookEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtBookEndDate').val(Dt.format("MM/dd/yyyy"));
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_BookEndDate').css("display", 'none');
    var date1 = new Date($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayStartDate').val());
    var date2 = new Date($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtDisplayEndDate').val());
    var diffDays = 0;
    if (date2 < date1) {
        diffDays = 0;
    }
    else {
        diffDays = (date2.getTime() - date1.getTime()) / (1000 * 3600 * 24);
    }
    $(".igte_EditInContainer")[0].value = Math.round(diffDays);
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_hdnDaysPrior').val(Math.round(diffDays));
}

function OfferSetupSetEndDate(sender, args) {
    var Dt = args.get_dates()[0];
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').focus();
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').val(Dt.format("MM/dd/yyyy"));

    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_EndDate').css("display", 'none');
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_StartDate').css("display", 'none');
}

function CheckChanged(e) {
    var value = "";
    var wdd = $find("ctl00_ContentPlaceHolder1_ctrlOfferSetup_ddlProperty");
    for (var i = 0; i < wdd.get_items().getLength(); i++) {
        if (e.target.checked) {
            value += wdd.get_items().getItem(i).get_text().trim() + ",";
            wdd.get_items().getItem(i).select(false);
        } else {
            wdd.get_items().getItem(i).unselect(false);
            value = "";
        }
    }
    value = value.replace(/,(?=\s*$)/, '');
    wdd.set_currentValue(value, true);
    //wdd.closeDropDown();
}

function CheckChangedLocation(e) {
    var value = "";
    var wdd = $find("ctl00_ContentPlaceHolder1_ctrlOfferSetup_ddlLocations");
    for (var i = 0; i < wdd.get_items().getLength(); i++) {
        if (e.target.checked) {
            /*value += wdd.get_items().getItem(i).get_text().trim() + ",";*/
            wdd.get_items().getItem(i).select(false);
        } else {
            wdd.get_items().getItem(i).unselect(false);
            value = "";
        }
    }
    /*value = value.replace(/,(?=\s*$)/, '');*/
    wdd.set_currentValue(value, true);
    //wdd.closeDropDown();
}

function UncheckALLSelecteionProperties() {
    if (!$(this).is(':checked') && $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_ddlProperty_ctl00_chkSelectAll").is(':checked')) {
        $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_ddlProperty_ctl00_chkSelectAll").prop("checked", false);
    }
}

function UncheckALLSelecteionLocation() {
    if (!$(this).is(':checked') && $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_ddlLocations_ctl00_chkSelectAllLocation").is(':checked')) {
        $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_ddlLocations_ctl00_chkSelectAllLocation").prop("checked", false);
    }
}

function OfferSetupAskConfirmation(fillFor, evt) {
    evt.stopPropagation();
    switch (fillFor) {
        case 1:
            if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_StartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_StartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_StartDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_EndDate').css("display", 'none');
            }
            break;
        case 2:
            if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_EndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_EndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_EndDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_StartDate').css("display", 'none');

            }
            break;
        case 3:
            if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate').css("display", 'none');
            }
            break;
        case 4:
            if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayEndDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_DisplayStartDate').css("display", 'none');
            }
            break;
        case 5:
            if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookStartDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookStartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookStartDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookEndDate').css("display", 'none');
            }
            break;
        case 6:
            if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookEndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookEndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookEndDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_CalendarViewmaster_BookStartDate').css("display", 'none');
            }
            break;

        case 7:
            if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayStartDate').is(":visible")) {
                $('ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayStartDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayStartDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate').css("display", 'none');
            }
            break;
        case 8:
            if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate').is(":visible")) {
                $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate').css("display", 'none');
            }
            else {
                $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayEndDate').css("display", 'block');
                $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_CalendarViewmaster_DisplayStartDate').css("display", 'none');
            }
            break;
              default:
            break;
    }
}

//$(document).delegate('.dateFormatExt', 'keydown', function (e) {
//    // Allow: backspace, delete, tab, escape, enter and .
//    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
//        // Allow: Ctrl+A, Command+A
//        (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
//        // Allow: home, end, left, right, down, up
//        (e.keyCode >= 35 && e.keyCode <= 40)) {
//        // let it happen, don't do anything
//        return;
//    }
//    // Ensure that it is a number and stop the keypress
//    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
//        e.preventDefault();
//    }
//    if (e.keyCode === 47) {
//        return false;
//    }
//});

//$(document).delegate('.dateFormatExt', 'keyup', function (e) {
//    if (e.which === 8 || e.which === 127) {
//    } else if (this.value.length === 2 || this.value.length === 5) {
//        this.value += "/";
//    }
//});

//function dateChangedStartDate(ev) {
//    $(this).datepicker('hide');
//    if (ev.date != undefined) {
//        var date = ev.date.toString();
//        var year = date.slice(-4),
//            month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].indexOf(date.substr(4, 3)) + 1,
//            day = date.substr(8, 2);

//        if (year == 'ime)') {
//            year = date.substr(11, 4)
//        }
//        var output = month + '/' + day + '/' + year;
//        $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate").val(output);
//        CompareDatesStartNew();
//    }
//}

//function dateChangedendDate(ev) {
//    $(this).datepicker('hide');
//    if (ev.date != undefined) {
//        var date = ev.date.toString();
//        var year = date.slice(-4),
//            month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].indexOf(date.substr(4, 3)) + 1,
//            day = date.substr(8, 2);

//        if (year == 'ime)') {
//            year = date.substr(11, 4)
//        }
//        var output = month + '/' + day + '/' + year;
//        $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate").val(output);
//        CompareDatesEnd();
//    }
//}

//function CompareDatesEnd() {
//    var dateStart = $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate").val();
//    var endDate = $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate").val();

//    var dateFirst = dateStart.split('/')
//    var dateSecond = endDate.split('/')
//    var value = new Date(dateFirst[2], dateFirst[0], dateFirst[1]); //Year, Month, Date
//    var current = new Date(dateSecond[2], dateSecond[0], dateSecond[1]);
//    if (current < value) {
//        SuccessMessage('End date cannot be less than Start Date');
//        $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate").val("");
//    }
//}

//function CompareDatesStartNew() {
//    var dateStart = $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate").val();
//    var endDate = document.getElementById("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate").val();
//    var dateFirst = dateStart.split('/')
//    var dateSecond = endDate.split('/')
//    var value = new Date(dateFirst[2], dateFirst[0], dateFirst[1]); //Year, Month, Date
//    var current = new Date(dateSecond[2], dateSecond[0], dateSecond[1]);
//    if (current < value) {
//        $("#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate").val(dateStart);
//    }
//}

function isPostBack() { //function to check if page is a postback-ed one    
    if ($('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_ispostbackvalue').val() == 'true') {
        return true;
    }
    else {
        return false;
    }
}

function initDropDown(sender, args) {
    $(sender.get_element()).find('input.igdd_ValueDisplay').on('focus', function () {
        this.blur();
    });
}

$(document).ready(function () {
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(function () {
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtStarttime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtStarttime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });

        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtEndtime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtEndtime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtMondayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtMondayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtMondayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtMondayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtTuesdayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtTuesdayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtTuesdayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtTuesdayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtWednesdayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtWednesdayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtWednesdayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtWednesdayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtThursdayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtThursdayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtThursdayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtThursdayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtFridayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtFridayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtFridayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtFridayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSaturdayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSaturdayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSaturdayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSaturdayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSundayStartTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSundayStartTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });
        if ($('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSundayEndTime').length > 0)
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSundayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });

        if ($('#txtMondayEndTime').length > 0)
            $('#txtMondayEndTime').timepicker({
                'showDuration': true,
                'timeFormat': 'g:ia'
            });


        $(".time.start").change(function () {
            if ($(this).val().indexOf("PM") > -1) {
                $(this).parent('div').addClass("darkbg");
            }
            if ($(this).val().indexOf("AM") > -1) {
                $(this).parent('div').removeClass("darkbg");
            }
        });

        $(".time.end").each(function () {
            if ($(this).val().indexOf("PM") > -1) {
                $(this).parent('div').addClass("darkbg");
            }
            if ($(this).val().indexOf("AM") > -1) {
                $(this).parent('div').removeClass("darkbg");
            }
        });
    });

    var postBackValue = isPostBack();
    if (postBackValue == false && $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_hdnOfferMasterId').val() == '0') {
        var today = new Date();
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStartDate').val(today.format("MM/dd/yyyy"));
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndDate').val(today.format("MM/dd/yyyy"));
        $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtDisplayEndDate').val(today.format("MM/dd/yyyy"));
    }


    $(".time.start").each(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.start").change(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.end").each(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });

    $(".time.end").change(function () {
        if ($(this).val().indexOf("PM") > -1) {
            $(this).parent('div').addClass("darkbg");
        }
        if ($(this).val().indexOf("AM") > -1) {
            $(this).parent('div').removeClass("darkbg");
        }
    });



    // for start time validation
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStarttime').blur(function () {

        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStarttime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtStarttime').val('');
            SuccessMessage('Start Time is invalid');
            return false;
        }
    });


    // for end time validation
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndtime').blur(function () {
        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndtime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_txtEndtime').val('');
            SuccessMessage('End Time is invalid');
            return false;
        }
    });

    // for start time validation for KioskDisplay
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtStarttime').blur(function () {
        console.log("test");
        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtStarttime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtStarttime').val('');
            SuccessMessage('Start Time is invalid');
            return false;
        }
    });


    // for end time validation for KioskDisplay
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtEndtime').blur(function () {
        var txtTime = $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtEndtime').val();
        if (validateTime(txtTime) || txtTime.length == 0) {
            return true;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtEndtime').val('');
            SuccessMessage('End Time is invalid');
            return false;
        }
    });

    // initialize input widgets first
    $('#basicScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#basicScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#basicBookScheduletime .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#basicBookScheduletime .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });

    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtStarttime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtEndtime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtMondayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtMondayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtTuesdayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtTuesdayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtWednesdayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtWednesdayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtThursdayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtThursdayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtFridayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtFridayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSaturdayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSaturdayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSundayStartTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });
    $('#ctl00_ContentPlaceHolder1_ctrlKioskDisplay_txtSundayEndTime').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });


    // initialize input widgets first
    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_dateSection .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    $('#ctl00_ContentPlaceHolder1_ctrlOfferSetup_dateSection .date').datepicker({
        'format': 'm/d/yyyy',
        'autoclose': true
    });
    // initialize datepair
    var basicExampleEl = document.getElementById('dateSection');
    var datepair = new Datepair(basicExampleEl);

    //InvitationDetail
    $(document).ready(function () {
        $(document).delegate("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnInvitationUpload", "click", function () {
            InvitationUploadClick();
            return false;
        });
    });
    $('.calendar.igmc_Control').click(function (evt) {
        evt.stopPropagation();
    })
    $(document).click(function () {
        $('.calendar.igmc_Control').css("display", 'none');
        $('.calendar.igmc_Control').click(function (evt) {
            evt.stopPropagation();
        })
    });
});
function validateTime(sTime) {
    var filter = /^([0]?[1-9]|1[0-2]):([0-5]\d)\s?(AM|PM)$/i;
    if (filter.test(sTime)) {
        return true;
    }
    else {
        return false;
    }
}



var validInvitationDetailFilesTypes = ["csv"];
function InvitationOverrideFileUploadChange() {
    var file = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_flOverride");
    var label = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblOverrideMessage");

    var fullPath = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_flOverride").val();
    label.text("");


    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var filename = fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);
            label.text(filename);
        }
    }
    label.removeClass('txt-middle-error');
    var path = file.val();
    var ext = path.substring(path.lastIndexOf(".") + 1, path.length).toLowerCase();
    var isValidFile = false;
    for (var i = 0; i < validInvitationDetailFilesTypes.length; i++) {
        if (ext == validInvitationDetailFilesTypes[i]) {
            isValidFile = true;
            break;
        }
    }
    if (!isValidFile) {
        label.addClass('txt-middle-error');
        label.text("Invalid File. Please upload a File with" +
            " extension:\n\n" + validInvitationDetailFilesTypes.join(", ") + ".");
    }

    if (isValidFile == true) {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnOverride").removeAttr("disabled");
    }
    else {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnOverride").prop("disabled", true);
    }
    return isValidFile;
}

function InvitationSegmentFileUploadChange() {

    var file = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_flUploadSegment");
    var label = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentMessage");

    var fullPath = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_flUploadSegment").val();
    label.text("");

    //var file = document.getElementById("<%=flUploadSegment");
    //var label = document.getElementById("<%=lblSegmentMessage");

    //var fullPath = document.getElementById("<%=flUploadSegment").value;
    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var filename = fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);
            label.text(filename);
        }
    }
    label.removeClass('txt-middle-error');
    var path = file.val();
    var ext = path.substring(path.lastIndexOf(".") + 1, path.length).toLowerCase();
    var isValidFile = false;
    for (var i = 0; i < validInvitationDetailFilesTypes.length; i++) {
        if (ext == validInvitationDetailFilesTypes[i]) {
            isValidFile = true;
            break;
        }
    }
    if (!isValidFile) {
        label.addClass('txt-middle-error');
        label.text("Invalid File. Please upload a File with" +
            " extension:\n\n" + validInvitationDetailFilesTypes.join(", ") + ".");
    }

    if (isValidFile == true) {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnChangeSegmentUpload").removeAttr("disabled");
    }
    else {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnChangeSegmentUpload").prop("disabled", true);
    }
    return isValidFile;
}

function InvitationFileUploadChange() {
    var file = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_flUpload");
    var label = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblFileName");

    var fullPath = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_flUpload").val();

    label.text("");
    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var filename = fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);

            label.text(filename);
        }
    }
    label.removeClass('txt-middle-error');
    var path = file.val();
    var ext = path.substring(path.lastIndexOf(".") + 1, path.length).toLowerCase();
    var isValidFile = false;
    for (var i = 0; i < validInvitationDetailFilesTypes.length; i++) {
        if (ext == validInvitationDetailFilesTypes[i]) {
            isValidFile = true;
            break;
        }
    }
    if (!isValidFile) {
        label.addClass('txt-middle-error');
        label.text("Invalid File. Please upload a File with" +
            " extension:\n\n" + validInvitationDetailFilesTypes.join(", ") + ".");
    }

    var hdnIsFileListUploaded = $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnIsFileListUploaded");
    if (hdnIsFileListUploaded.val() === 'Yes') {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnAppend').css('display', 'block');
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnAppend").removeAttr("disabled");
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDisabledAppend").css('display', 'none');

    }
    if (isValidFile == true) {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnInvitationUpload").removeAttr("disabled");
        if (hdnIsFileListUploaded.val() === 'Yes') {
            $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnAppend').css('display', 'block');
            $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnAppend").removeAttr("disabled");
            $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDisabledAppend").css('display', 'none');
        }
    }
    else {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnInvitationUpload").prop("disabled", true);
        //$("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnAppend").prop("disabled", true);
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnAppend").css('display', 'none');
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDisabledAppend").css('display', 'block');
    }
    return isValidFile;
}
function OpenInvitationEmailPopup() {
    document.querySelector("#emailPopup").classList.toggle("active");
}

function OpenInvitationChangeSegmentPopup() {
    document.querySelector("#changeSegmentPopup").classList.toggle("active");
}





function DismissAlertPop() {
    $('#mask').hide();
    $('.window').hide();
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lbtAlertMessage').text("");
}
//Internal Attachement
var IsDataChanged = false;
function grdOfferAttachment_Editing_CellValueChanged(sender, eventArgs) {
    IsDataChanged = true;
}

$(document).click(function (e) {
    if ($(e.target).parents(".popup-box").length === 0) {
        $(".popup-box").hide();
    }
});

function callUpdateDeletePopup(param, e) {
    $(".popup-box").hide();
    $(param).next().show();
    e.stopPropagation();
}

$(document).on('change', '#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType', function () {
    $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg").hide();
    if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "0") {
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trFileUpload").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalURL").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalURL").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalNote").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalNote").hide();
        return false;
    }
    else if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "1") {
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trFileUpload").show();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalURL").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalURL").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalNote").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalNote").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblFileName").text("Select a file");
        return false;
    }
    else if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "2") {
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trFileUpload").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalURL").show();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalURL").show();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalNote").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalNote").hide();
        return false;
    }
    else if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "3") {
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trFileUpload").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalURL").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalURL").hide();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_trInternalNote").show();
        $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_tdInternalNote").show();
        return false;
    }
});

function ValidateInternalAttachement(btnId) {
    var btn = document.getElementById(btnId);
    if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "0") {
        $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').text("Please select type of attachment.");
        btn.disabled = false;
        return false;
    }
    else if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "1") {
        if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_flInternalAttachment").val() == "") {
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').show();
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').text("Please Upload File.");
            btn.disabled = false;
            return false;
        }
        else {
            btn.disabled = true;
            return InternalAttachementFileUploadChange();
        }
    }
    else if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "2") {
        if (($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalURL").val() == "") ||
            (!$("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalURL").val().replace(/\s/g, '').length)) {
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').show();
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').text("Please Enter Internal URL.");
            btn.disabled = false;
            return false;
        }
        else {

            if (checkUrl($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalURL").val()) == true) {
                btn.disabled = true;
                return true;
            }
            else {
                btn.disabled = false;
                return false;
            }
        }
    }
    else if ($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_ddlAttachmentType").val() == "3") {
        if (($("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalNote").val() == "") ||
            (!$("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalNote").val().replace(/\s/g, '').length)) {
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').show();
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').text("Please Enter Internal Note.");
            btn.disabled = false;
            return false;
        }
    }
    else {
        btn.disabled = true;
        $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').hide();
    }

    if ($('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalNote').val() != "") {
        var notesLength = $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_txtInternalNote').val();
        if (notesLength.length > 240) {
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').show();
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').text("Internal notes length cannot exceed 240 characters.");
            btn.disabled = false;
            return false;
        }
        else {
            btn.disabled = true;
            $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').hide();
            return true;
        }
    }
}

//function used to validate website URL
function checkUrl(url) {
    //regular expression for URL
    var pattern = /^(http|https)?:\/\/[a-zA-Z0-9-\.]+\.[a-z]{2,4}/;

    if (pattern.test(url)) {
        return true;
    } else {
        $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').text("Website Link must be a valid url (http://link).");
        return false;
    }
}

var validInternalAttachementFilesTypes = [".doc", ".docx", ".xls", ".xlsx", ".pdf", ".csv", ".jpg", ".png", ".flv", ".mov", ".wmv", ".avi", ".mp4"];
function InternalAttachementFileUploadChange() {
    $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblMsg').hide();
    var file = $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_flInternalAttachment");
    var label = $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_lblFileName");
    label.text("");
    var fullPath = $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_flInternalAttachment").val();
    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var filename = fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);
            label.text(filename);
        }
    }
    label.removeClass('txt-middle-error');
    var path = file.val();
    var ext = path.substring(path.lastIndexOf("."), path.length).toLowerCase();
    var isValidFile = false;
    for (var i = 0; i < validInternalAttachementFilesTypes.length; i++) {
        if (ext == validInternalAttachementFilesTypes[i]) {
            isValidFile = true;
            break;
        }
    }
    if (!isValidFile) {
        label.addClass('txt-middle-error');
        label.text("Invalid File. Please upload a File with" +
            " extension:\n\n" + validInternalAttachementFilesTypes.join(", ") + ".");
    }
    return isValidFile;
}

function SetOfferAttachmentID(OfferAttachmentID, FileID) {
    $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_hdnOfferAttachmentID').val(OfferAttachmentID);
    $('#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_hdnFileID').val(FileID);
}

function DownloadFile(ID) {
    $("#ctl00_ContentPlaceHolder1_ctrlInternalAttachment_grdOfferAttachment_it4_" + ID + "_btnDownload").click();
}
function wdgFileList_OnRowSelectionChanged(webDataGrid, evntArgs) {
    var Fileid = webDataGrid.get_behaviors().get_selection().get_selectedRowsResolved()[0].get_cell(2).get_value();
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnFileID').val(Fileid);
    if (Fileid > 0) {

        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDelete').prop("disabled", false);
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDelete').prop("disabled", true);
    }
}

function ValidateMasterItem() {
    $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").hide();
    if (($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtDisplayPrizeName").val() == "") ||
        (!$("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtDisplayPrizeName").val().replace(/\s/g, '').length)) {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').show();
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').text("Please enter Display Prize Name.");
        $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").show();
        return false;
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').hide();
    }

    if ($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPhysicalInverntery").val() == "" ||
        $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPhysicalInverntery").val() == "0") {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').show();
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').text("Physical Inventory should not be empty or 0.");
        $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").show();
        return false;
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').hide();
    }

    if ($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtNoShow").val() == "") {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').show();
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').text("No Show should not be empty.");
        $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").show();
        return false;
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').hide();
    }

    if ($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPhysicalInverntery").val() != "") {

        var notesLength = $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtPhysicalInverntery').val();

        if (notesLength.length > 6) {
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').show();
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').text("Physical Inventory should not more than 6 digits.");
            $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").show();
            return false;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').hide();
        }
    }

    if ($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnTotalBookedInventory").val() != "") {
        if (parseInt($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_txtBookingLimit").val()) < parseInt($("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_hdnTotalBookedInventory").val())) {
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').show();
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').text("Physical inventory can not be less than prizes booked.");
            $("#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_btnSave").show();
            return false;
        }
        else {
            $('#ctl00_ContentPlaceHolder1_ctrlMasterListOfItem_lblMasterItemErrorMsg').hide();
        }
    }

}

function ValidateSegmentChange() {


    var currentSegemnt = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlCurrentSegment').val();
    var newSegemnt = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlNewSegment').val();

    if (currentSegemnt == "-Select-") {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').text("Please select current segment from the list.");
        return false;
    } else if (newSegemnt == "-Select-") {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').text("Please select new segment from the list.");
        return false;
    }

    return true;

}

function ValidateOverrideSavebtn() {


    var IsSegmentFileUploaded = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnIsOverrideFileUploaded').val();
    var SegmentFileId = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnOverrideFileID').val();

    if (IsSegmentFileUploaded == "Yes" && SegmentFileId != "") {
        return true
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblOverrideError').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblOverrideError').text("Please upload override file first.");
        return false;
    }

}

function ValidateSegmentSavebtn() {


    var IsSegmentFileUploaded = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnIsSegmentFileUploaded').val();
    var SegmentFileId = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnSegementFileID').val();

    var currentSegemnt = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlCurrentSegment').val();
    var newSegemnt = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlNewSegment').val();

    if (currentSegemnt == "-Select-") {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').text("Please select current segment from the list.");
        return false;
    } else if (newSegemnt == "-Select-") {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').text("Please select new segment from the list.");
        return false;
    }

    if (IsSegmentFileUploaded == "Yes" && SegmentFileId != "") {
        return true
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').show();
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').text("Please upload segment file first.");
        return false;
    }

}

function ResetSegmentMessages() {
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentError').hide();
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblSegmentMessage').text("No file selected");
}

function AddValidation() {
    if ($('#ctl00_ContentPlaceHolder1_ctrlSummary_txtRejectReason').val().trim() == "") {
        $('#ctl00_ContentPlaceHolder1_ctrlSummary_lblErrorMessage').show();
        $('#ctl00_ContentPlaceHolder1_ctrlSummary_lblErrorMessage').text("Please Enter Reject Reason.");
        return false;
    }
    else {
        $('#ctl00_ContentPlaceHolder1_ctrlSummary_lblErrorMessage').hide();
        return true;
    }
}

//Check-in
function isAlphaNumericKey(evt) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var str = String.fromCharCode(!evt.charCode ? evt.which : evt.charCode);
    if (regex.test(str)) {
        return true;
    }

    evt.preventDefault();
    return false;
}

function SetDefaultSegment() {

    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlCurrentSegment').val("-Select-");
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlNewSegment').val("-Select-");
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnIsSegmentFileUploaded').val("");
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_hdnSegementFileID').val("");
}

function cSegemntSelectionChange() {
    var currentSegment = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlCurrentSegment').val();

    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlNewSegment').children('option').show();

    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlNewSegment').children("option[value^=" + currentSegment + "]").hide();

}
function nSegemntSelectionChange() {
    var currentSegment = $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlNewSegment').val();

    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlCurrentSegment').children('option').show();

    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_ddlCurrentSegment').children("option[value^=" + currentSegment + "]").hide();
}

/* Invitation Details - Invitee Upload Progress Start */

var inviteeUploadProgressTimer;

function InvitationUploadClick() {
    if (inviteeUploadProgressTimer != undefined) {
        clearTimeout(inviteeUploadProgressTimer);
    }
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnInvitationUpload").attr("disabled", "disabled");
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_progressBar").hide();
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnInvitationUploadClick").click();
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_updPgInviteeUpload").addClass("progressLoader");
    return false;
}

/* Invitation Details - Invitee Upload Progress End */

//Code for Scrolling issue in WebDropdown for inner Scroll

var DivScroll = 0;
function TriggerScrollEvent() {
    setTimeout(function () {
        $(".row").niceScroll({ mousescrollstep: 8, smoothscroll: true, autohidemode: false, cursorcolor: "#C1C1C1", cursorwidth: "10px" });
        $('.row').scroll(function () {
            if ($('[id$=":mkr:DropDown_animations"]:visible').length > 0) {
                $('[id$=":mkr:DropDown_animations"]:visible').each(function (i, v) {
                    $(v).css('margin-top', parseFloat($(v).css('margin-top').replace('px', '')) - (parseFloat($('.row').scrollTop()) - DivScroll));
                });
            }
            DivScroll = parseFloat($('.row').scrollTop());
        });
    }, 50);
}
function DropdownOpeningEvent(sender, args) {
    setTimeout(function () {
        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");

        if ($('[id$=":mkr:DropDown_animations"]:visible').length > 0) {
            $('[id$=":mkr:DropDown_animations"]:visible').each(function (i, v) {
                var updatedmargin = 0;
                if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                    updatedmargin = parseFloat($(v).css('margin-top').replace('px', '')) - (parseFloat($('.row').scrollTop()));
                }
                else {
                    updatedmargin = parseFloat($(v).css('margin-top').replace('px', '')) - (parseFloat($('.row').scrollTop()) - DivScroll);
                }
                $(v).css('margin-top', updatedmargin);
            });
        }
        DivScroll = parseFloat($('.row').scrollTop());
        $('[id$=":mkr:DropDown_animations"]').css('width', sender._element.offsetWidth);
    }, 1);
}

function CalculateBookingLimitForAttendeeCapacity() {
    var maxAtt = $('#ctl00_ContentPlaceHolder1_ctrlAttendeeCapacity_txtMaximunAttendeeCapacity').val();
    var nShow = $('#ctl00_ContentPlaceHolder1_ctrlAttendeeCapacity_hdnExpectedNoShowPercent').val();
    if (maxAtt == '') {
        //document.getElementById('ctl00_ContentPlaceHolder1_ctrlAttendeeCapacity_txtBookingLimit').innerText = 'NaN';  //Commented against BUG#18703
        document.getElementById('ctl00_ContentPlaceHolder1_ctrlAttendeeCapacity_txtBookingLimit').innerText = '0';      //Wok against BUG#18703
    }
    else {
        var total = Math.round(parseInt(maxAtt) / (1 - nShow / 100));
        if (maxAtt != "" && nShow != "") {
            document.getElementById('ctl00_ContentPlaceHolder1_ctrlAttendeeCapacity_txtBookingLimit').innerText = total.toString();
        }
    }
}


//Code for Scrolling issue in WebDropdown for inner Scroll


/* Invitation Details - Invitee Upload Progress Start */

function StartUploadProgress() {
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_progressBar").show();
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblUploadStatus").text("File upload successful, processing invitations.");
    $('#ctl00_ContentPlaceHolder1_btnSaveNext').prop("disabled", false);
    $('#ctl00_ContentPlaceHolder1_btnPreviousStep').prop("disabled", false);
    DisableControlButtons(true);
    inviteeUploadProgressTimer = setTimeout(function () {
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_updPgInviteeUpload").addClass("progressLoader");
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnRefreshSegmentDetails").click();
    }, 1000);
}

function EndUploadProgress() {
    DisableControlButtons(false);
    if (inviteeUploadProgressTimer != undefined) {
        clearTimeout(inviteeUploadProgressTimer);
    }
}

function DisableControlButtons(isDisabled) {
    if (isDisabled == true) {
        $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnDelete').prop("disabled", isDisabled);
    }
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnChangeSegment').prop("disabled", isDisabled);
    $('#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_btnOverride').prop("disabled", isDisabled);
}

function ShowFileUploadProgress(percentage) {
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_progressBar").show();
    setTimeout(function() { $("#myBar").width("" + percentage + "%") }, 100);
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_updPgInviteeUpload").hide();
    if (percentage == 100) {
        EndUploadProgress();
        $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblUploadStatus").text("Invitations processed successfully!");
    }
    else {
        StartUploadProgress();
    }
}

function FileUploadProgressError() {
    EndUploadProgress();
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_updPgInviteeUpload").hide();
    $("#progressBar").show();
    $("#ctl00_ContentPlaceHolder1_ctrlInvitationDetails_lblUploadStatus").text("File upload successfull, error during invitations processing.");
}

function DisablePreviousNextStep() {
    $('#ctl00_ContentPlaceHolder1_btnSaveNext').prop("disabled", true);
    $('#ctl00_ContentPlaceHolder1_btnPreviousStep').prop("disabled", true);
}

function pageLoad(sender, args) {
    bindControlML();
    BindAutoComplete();
    bindControl();
}

/* Invitation Details - Invitee Upload Progress End */

function ReplaceStyle1Attribute() {
    $("ul").find('[style1]').each(function () {
        var $this = $(this);
        var bgColor = $this.attr("style1");
        $this.attr("style", bgColor);
        $this.removeAttr("style1");
    });
}

function onlyNumbers(event) {
    var charValue = String.fromCharCode(keyCode);
    if (isNaN(parseInt(charValue)) && event.keyCode != 8) {
        event = event || window.event // IE support
        var c = event.keyCode
        var ctrlDown = event.ctrlKey || event.metaKey // Mac support
        if (ctrlDown) {
            if (ctrlDown && c == 86) {
                var clipboardData = event.clipboardData || window.clipboardData;
                //var pastedData = clipboardData.getData('Text');
                if (event.clipboardData != null / false / undefined) { //ignore the incorrectness of the truncation
                    var clipboarddata = event.clipboardData;
                } else if (window.clipboardData != null / false / undefined) {
                    var clipboarddata = window.clipboardData;
                } else { //default to the last option even if it is null/false/undefined
                    var clipboarddata = event.originalEvent.clipboardData;
                }
                if (pastedData == undefined) {
                    event.type == "paste";
                }
                else if (isNaN(pastedData) && pastedData != undefined) {
                    event.preventDefault();
                }
                else {
                    return;
                }
            }
        }
    }
    if (event.type == "paste") {
        var clipboardData = event.clipboardData || window.clipboardData;
        var pastedData = clipboardData.getData('Text');
        if (isNaN(pastedData)) {
            event.preventDefault();
        } else {
            return;
        }
    }
    var keyCode = event.keyCode || event.which;
    if (keyCode >= 96 && keyCode <= 105) {
        // Numpad keys
        keyCode -= 48;
    }
}

///*New methods for Offer Setup drop down client Callbacks*/
var _IsChangeValueFlag = false;
function ddlLOBClosed(sender, args) {
    if (_IsChangeValueFlag) {
        _IsChangeValueFlag = false;
        ShowLoader();
        setTimeout('__doPostBack(\'ddlLOB\',\'\')', 0);
        //var cbo = sender._callbackManager.createCallbackObject();
        //sender._callbackManager.execute(cbo, true);
        //selectionChanged = true;
    }
    $(".igdd_DropDownListContainer").css("visibility", "hidden");
}

function ddlRegionClosed(sender, args) {
    if (_IsChangeValueFlag) {
        _IsChangeValueFlag = false;
        ShowLoader();
        setTimeout('__doPostBack(\'ddlRegion\',\'\')', 0);
    }
    $(".igdd_DropDownListContainer").css("visibility", "hidden");
}

function ddlPropertyClosed(sender, args) {
    if (_IsChangeValueFlag) {
        _IsChangeValueFlag = false;
        ShowLoader();
        setTimeout('__doPostBack(\'ddlProperty\',\'\')', 0);
    }
}

function ddlLocationClosed(sender, args) {
    if (_IsChangeValueFlag) {
        _IsChangeValueFlag = false;
        ShowLoader();
        setTimeout('__doPostBack(\'ddlLocation\',\'\')', 0);
    }
}

function CheckUncheckAllOptions(e) {
    if (e.checked)
        $("#hdnChkAll").val("1");
    else
        $("#hdnChkAll").val("0");

    CheckChanged(e);
    setTimeout('__doPostBack(\'chkSelectAll\',\'\')', 0);
}

function CheckUncheckAllOptionsLoc(e) {
    if (e.checked)
        $("#hdnChkAllLoc").val("1");
    else
        $("#hdnChkAllLoc").val("0");

    CheckChangedLocation(e);
    setTimeout('__doPostBack(\'chkSelectAllLocation\',\'\')', 0);
}

function updateIschangeFlag(sender, args) {
    _IsChangeValueFlag = true;
}
function ddlOfferTypeClosed(sender, args) {
    if (_IsChangeValueFlag) {
        _IsChangeValueFlag = false;
        ShowLoader();
        setTimeout('__doPostBack(\'ddlOfferType\',\'\')', 0);
    }
    $(".igdd_DropDownListContainer").css("visibility", "hidden");
}
function updateIschangeFlagOffer(sender, args) {
    _IsChangeValueFlag = true;
}

//added by sanjay for ticket 19961
var currentValue;
function SetCurrentValue(ctrl) {
    var ddlCombo = "#ctl00_ContentPlaceHolder1_ctrlCheckIn_" + ctrl;
    currentValue = $(ddlCombo).val();
}

function CaptureFieldChange(ctrl) {
    var allCombo = $('select.CaptureField');
    var captureCombo = "#ctl00_ContentPlaceHolder1_ctrlCheckIn_" + ctrl;
    var selectedValue = $(captureCombo).val();
    var otherComboSelectedValues = allCombo.not($(captureCombo)).children("option:selected ");
    var canSelect = true;
    otherComboSelectedValues.each(function () {
        if (selectedValue != "-Select-")
        {
            if ($(this).val() == selectedValue) {
                PumaMessage("This Capture Field Value is already selected.", "");
                canSelect = false;
                return false;
            }
        }
    });

    if (!canSelect) {
        $(captureCombo).val(currentValue);
    }
}