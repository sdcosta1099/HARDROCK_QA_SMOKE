// TODO: Remove these from the global scope

//(function ($) {
//    'use strict';

function firstloginpopup(msg) {
    document.getElementById('popuplogin').style.display = 'block';
    document.getElementById('messagearea3').innerHTML = msg;
}

function divpopup(wr) {
    var maskHeight = $(document).height();
    var maskWidth = $(window).width();

    //Set heigth and width to mask to fill up the whole screen
    $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

    //transition effect		
    $('#mask').fadeIn(1000);
    $('#mask').fadeTo("slow", 0.5);

    ////Get the window height and width
    //var winH = $(window).height();
    //var winW = $(window).width();

    ////Set the popup window to center
    //$('#foo').css('top', (winH + 180) / 2 - $('#foo').height());
    //$('#foo').css('left', winW / 2 - $('#foo').width() / 2);

    document.getElementById('foo').style.display = 'block';
    document.getElementById('messagearea').innerHTML = wr;
    PasswordExpire();
}

function showPwdExpMessage(Msg) {
    execScript('n = msgbox("' + Msg + '","4132","MGM MLife App")', "vbscript", "Mlife");
    if (n == 6) {
        document.getElementById("navloginchpass").click();
    }
    else {
        document.getElementById("Submit").click();
    }
}

function PasswordExpire() {
    var waitperiod = $("#hidnWaitPeriod").val();
    var miliwaitperiod = waitperiod * 1000;
    setInterval("alertIdeal()", miliwaitperiod);
}

function alertIdeal() {
    document.getElementById('btnNo').click();
}

function positionAjaxIndicator() {
    document.getElementById("dvProgressBar").style.top = document.getElementById("loginarea").style.top + 350;
    document.getElementById("dvProgressBar").style.left = document.getElementById("loginarea").style.left + 500;
}

function btnCancelClick() {
    document.getElementById("txtUserame").value = '';
    document.getElementById("txtPassword").value = '';
    document.getElementById("ddlDomain").value = 0;
}

//})(window.jQuery);