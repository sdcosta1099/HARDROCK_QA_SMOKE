// TODO: Remove these from the global scope

var countInterval = null;

$(document).ready(function () {
    if (window.history && window.history.pushState) {
        $(window).on('popstate', function () {
            var hashLocation = location.hash;
            var hashSplit = hashLocation.split("#!/");
            var hashName = hashSplit[1];
            if (hashName !== '') {
                var hash = window.location.hash;
                if (hash === '') {
                    window.history.go(-1);
                    location.reload(true);
                }
            }
        });
        window.history.pushState('forward', null, null);
    }

    //if Close button is clicked
    $('.window #close').click(function () {
        $('#mask').hide();
        $('.window').hide();

    });

    $('.window #button').click(function () {
        $('#mask').hide();
        $('.window').hide();
    });

    //    $('.blink').each(function () {
    //        var elem = $(this);
    //        setInterval(function () {
    //            if (elem.css('visibility') == 'hidden') {
    //                elem.css('visibility', 'visible');
    //            } else {
    //                elem.css('visibility', 'hidden');
    //            }
    //        }, 500);
    //    });

    $('.exp').each(function () {
        var elem = $(this);
        alert("Hi");
        elem.css('color', '#BA0202');
    });

    $(".notification-popup, .notification-icon").on('click', function (e) {
        e.stopPropagation();
    });
});


$(window).resize(function () {
    if (PlayerId1 != 0) {
        if ($("#ctl00_FramePopUp1").is(":visible")) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(1000);
            $('#mask').fadeTo("slow", 0.5);

            // call the popup inside the iframe
            LoadPopup_Url(url1 + '&PlayerId=' + PlayerId1, headerName1);

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();

            //Set the popup window to center
            $(id1).css('top', (winH + 100) / 2 - $(id1).height());
            $(id1).css('left', winW / 2 - $(id1).width() / 2);

            //transition effect
            $(id1).fadeIn(2000);
            itr = 0;

            //when window re-sized keep the popup window to center
            $(window).resize(function () {
                //get window width
                var winW = $(window).width();

                //Set the popup window to center
                $(id).css('left', winW / 2 - $(id).width() / 2);

                //Get the screen height and width
                var maskHeight = $(document).height();
                var maskWidth = $(window).width();

                //Set heigth and width to mask to fill up the whole screen
                $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
            });
        }
        else if (itr != 1) {
           
            //Commented $('#mask').hide(); and $('.window').hide();
            //Changes assocated with ticket no. #16933 Web App - Screen adjustments revert to the previous screen

            //e.preventDefault();
            //$('#mask').hide();
            //$('.window').hide();
        }
        $('.window #close').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });

    }

    if ($("#dialog2").is(":visible")) {
        var id = '#dialog2';
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(500);
        $('#mask').fadeTo("slow", 0.5);

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', (winH + 100) / 2 - $(id).height());
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr1 = 0;
        var dvtitle = document.getElementById("popupheader2");

        var dvmsg = document.getElementById("dvpopupmsg1");

        dvmsg.innerHTML = document.getElementById("ctl00_msg1").value;
        dvtitle.innerHTML = document.getElementById("ctl00_title1").value;

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }

    $('.window #close').click(function () {
        $('#mask').hide();
        $('.window').hide();
    });

    $('.window #button').click(function () {
        $('#mask').hide();
        $('.window').hide();
    });
});

function SetPopupHeader(headername) {
    $("#hd").text(headername);
}

function Redirect() {
    window.location.href = "Home.aspx";
}

function removeHead() {
    $("#popupheader").hide();
}

function showHead() {
    $("#popupheader").show();
}

function showConsentHead() {
    $("#popupheaderConsent").show();
}

function Update() {
    document.getElementById("ctl00_hdnLnkredirect").click();
}

function toggle() {
    var ele = document.getElementById("search-advance");
    var ico = document.getElementById("t-icon");
    var tico = document.getElementById("toggle-icon");

    if (ele.style.display == "block") {
        ele.style.display = "none";
        ico.style.background = 'url(images/icon-expand.png) no-repeat';
        tico.style.padding = "20px 0px 0px 0px";
    }
    else {
        ele.style.display = "block";
        ico.style.background = 'url(images/icon-collapse.png) no-repeat';
        tico.style.padding = "30px 0px 0px 0px";
    }
}

function isDateWithValidYear(dateStr) {
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{2}|\d{4})$/;

    // To require a 4 digit year entry, use this line instead:
    //var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{2})$/;

    var matchArray = dateStr.match(datePat); // is the format ok?
    if (matchArray == null) {
        return false;
    }

    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[4];


    if (month < 1 || month > 12) { // check month range
        return false;
    }

    if (day < 1 || day > 31) {
        return false;
    }

    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false
    }

    if (month == 2) {
        // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;  // date is valid
}

function ValidateSearch() {
    var values;
    var ele = document.getElementById("dvpopup");
    var msg = document.getElementById("dvpopupmsg");

    var hidAllowSearch = document.getElementById("ctl00_hidAllowSearch");
    if (hidAllowSearch.value != "1") {
        PumaMessage("You do not have patron search permission!", "");
        return false;
    }
    var txtPlayerId = document.getElementById("ctl00_txtPlayerId");
    var txtlastname = document.getElementById("ctl00_txtlastname");
    //var txtmiddle = document.getElementById("ctl00_txtmiddle");
    var txtfirstname = document.getElementById("ctl00_txtfirstname");
    var txtcity = document.getElementById("ctl00_txtcity");
    var txtstate = document.getElementById("ctl00_txtstate");
    var txtCountry = document.getElementById("ctl00_txtCountry");
    var txtEmailAddress = document.getElementById("ctl00_txtEmailAddress");
    var txtdob = document.getElementById("ctl00_txtdob");

    var ddlProperty = document.getElementById("ctl00_ddlProperty");
    var ddlPropertyValue = ddlProperty.options[ddlProperty.selectedIndex].value;

    if (txtdob.value != "  /  /    " && txtdob.value != "" && txtdob.value != "Birthday (mm/dd/yyyy)") {
        if (!isDateWithValidYear(txtdob.value)) {
            txtdob.value = "";
            PumaMessage("Valid DOB must be entered!", "");
            return false;
        }
        else {
            values = values + txtdob.value;
            return true;
        }
    }
    else if (txtPlayerId.value != "" && txtPlayerId.value != "Player Id") {
        values = txtPlayerId.value;
        return true;
    }
    else if (txtlastname.value != "" && txtlastname.value != "Last Name") {
        values = values + txtlastname.value;
        return true;
    }
    //else if (txtmiddle.value != "" && txtmiddle.value != "Middle Initial") {
    //    values = values + txtmiddle.value;
    //    return true;
    //}
    else if (txtfirstname.value != "" && txtfirstname.value != "First Name") {
        values = values + txtfirstname.value;
        return true;
    }
    else if (txtcity.value != "" && txtcity.value != "City") {
        values = values + txtcity.value;
        return true;
    }
    else if (txtstate.value != "" && txtstate.value != "State") {
        values = values + txtstate.value;
        return true;
    }
    else if (txtCountry.value != "" && txtCountry.value != "Country") {
        values = values + txtCountry.value;
        return true;
    }
    else if (txtEmailAddress.value != "" && txtEmailAddress.value != "Email Address") {
        values = values + txtEmailAddress.value;
        return true;
    }
    else if (ddlPropertyValue != "0") {
        values = values + ddlPropertyValue;
        return true;
    }
    else {
        return false;
    }
}

function ValidateSearch1(title) {
    var dvtitle = document.getElementById("dvpopupheader");
    var ele = document.getElementById("dvpopup");
    var msg = document.getElementById("dvpopupmsg");
    var srch = document.getElementById("ctl00_hdnsearch");

    if (srch.value == "1") {
        document.getElementById("ctl00_txtPlayerId").value = "Player Id";
        ele.style.display = "block";
        msg.innerHTML = "Player not found";
        dvtitle.innerHTML = title;
        srch.value = "0";
    }
}

function checkkey(evt) {
    evt = (window.event) ? window.event : evt;
    keycode = (evt.charCode) ? evt.charCode : evt.keyCode;
    if (evt.ctrlKey && evt.altKey && keycode == 79) {
        var ele = document.getElementById("search-advance");
        var ico = document.getElementById("t-icon");
        var tico = document.getElementById("toggle-icon");
        ele.style.display = "block";
        ico.style.background = 'url(images/icon-collapse.png) no-repeat';
        tico.style.padding = "30px 0px 0px 0px";
        document.getElementById("ctl00_txtlastname").value = "";
        document.getElementById("ctl00_txtlastname").focus();
        return false; // Prevent any default browser behaviour
    }
}

function toggle1(navid, MenuName, first) {
    loadXMLDoc("AjaxUtility.aspx?MenuId=" + navid + "&Parent=" + navid, '', MenuName, '');

    var mainNav = $('#main_nav_' + navid);
    var subNav = $('#sub_nav_' + navid);
    var hdnPrev = $('#ctl00_hdnprevid')[0];
    var prevsId = hdnPrev.value;
    hdnPrev.value = navid;

    $('#main_nav_' + first).css({ borderTop: '5px solid' });
    mainNav.toggleClass('nav-expanded');
    subNav.toggle();
}

function togglesub(navid, MenuName) {
    loadXMLDoc("AjaxUtility.aspx?MenuId=" + navid + "&Sub=" + navid, '', MenuName, '');

    $('#main_nav_' + navid).toggleClass('nav-expanded');
    $('#sub_nav_' + navid).toggle();
    document.getElementById("ctl00_hdnsubid").value = navid;
}

function launchExclusionPopUp(id, url, headerName, PlayerId) {
    if (itr == 0) {
        PlayerId1 = PlayerId;
        id1 = id;
        url1 = url;
        headerName1 = headerName;
        if (PlayerId != 0) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(1000);
            $('#mask').fadeTo("slow", 0.5);

            document.getElementById('ctl00_FramePopUp5').src = "";
            document.getElementById('ctl00_FramePopUp5').src = url;
            document.getElementById("popupheader5").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('top', (winH + 180) / 2 - $(id).height());
            $(id).css('left', winW / 2 - $(id).width() / 2);

            if (url.indexOf("IssueCompBCLC.aspx") > -1) {
                $(id + ' .popup-content-page').addClass('popup-content-page-issuePage');
                $(id).addClass('windowdisassociated');
                $(id).addClass('window-issuePage-bclc');
            }
            else {
                $(id).removeClass('window-issuePage-bclc');
                $(id + ' .popup-content-page').removeClass('popup-content-page-issuePage');
            }

            //transition effect
            $(id).fadeIn(2000);
            itr = 0;

            //when window re-sized keep the popup window to center
            $(window).resize(function () {
                //get window width
                var winW = $(window).width();

                //Set the popup window to center
                $(id).css('left', winW / 2 - $(id).width() / 2);

                //Get the screen height and width
                var maskHeight = $(document).height();
                var maskWidth = $(window).width();

                //Set heigth and width to mask to fill up the whole screen
                $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
            });
        }

        if ($(id).is(":visible") == true) { //Exclusion popup have more priority then others so set Z-index here
            var boxes = $("div.window, div.popup , div.dialog"); //Get All divs in current page which contains this classes
            var max = 0;
            // Find the highest z-index
            boxes.each(function () {
                // Find the current z-index value
                var z = parseInt($(this).css("z-index"), 10);
                if (isNaN(z)) {
                    $(this).css('z-index', 1); //if element have no Z-Index, then assign it
                }
                else {
                    // Keep either the current max, or the current z-index, whichever is higher
                    max = Math.max(max, z);
                }
            });
            $(id).css('z-index', max + 1);
        }

        if (itr != 0 && !$("#ctl00_FramePopUp5").is(":visible")) {
            //e.preventDefault();
            $('#mask').hide();
            $('.window').hide();
        }

        $('.window #close').click(function () {
            $('.window').find('.popup-content-page-issuePage').removeClass('popup-content-page-issuePage');
            $('.window').removeClass('windowdisassociated');
            $('.window').removeClass('window-issuePage-bclc');
            $('#mask').hide();
            $('.window').hide();
        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });
    }
}

function LaunchNotificationPopup() {
    var modal = document.getElementById("NotificationPopup");
    if (modal.style.display == "block") {
        modal.style.display = "none";
    }
    else {
        modal.style.display = "block";
    }

}

function launchWindow(id, url, headerName, PlayerId) {
    console.log(id);
    if (itr == 0) {
        PlayerId1 = PlayerId;
        id1 = id;
        url1 = url;
        headerName1 = headerName;
        if (PlayerId != 0) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(1000);
            $('#mask').fadeTo("slow", 0.5);

            LoadPopup_Url(url + '&PlayerId=' + PlayerId, headerName);
            if (headerName !== null && headerName !== '')
            {
                if (headerName.toLowerCase() === 'credit sync' || headerName.toLowerCase() === 'safekeeping account') {
                    $("#popupheader").removeClass('popup-header').addClass('popup-header-credit');
                }
                else {
                    $("#popupheader").removeClass('popup-header-credit').addClass('popup-header');
                }
            }
            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();
            
            //Set the popup window to center
            if (headerName === 'Adjust Bucket Value') {
                $(id).css('top', 0);
            }
            else {
                $(id).css('top', (winH + 180) / 2 - $(id).height());
            }
            $(id).css('left', winW / 2 - $(id).width() / 2);

            if (url.indexOf("IssueCompBCLC.aspx") > -1) {
                $(id + ' .popup-content-page').addClass('popup-content-page-issuePage');
                $(id).addClass('windowdisassociated');
                $(id).addClass('window-issuePage-bclc');
            }
            else {
                $(id).removeClass('window-issuePage-bclc');
                $(id + ' .popup-content-page').removeClass('popup-content-page-issuePage');
            }

            if (url.indexOf("AddTerminals_Popup.aspx") > -1) {
                $(id + ' .popup-content-page').addClass('popup-content-page-addTerminal');
            }
            else {
                $(id + ' .popup-content-page').removeClass('popup-content-page-addTerminal');
            }

            //transition effect
            $(id).fadeIn(2000);
            itr = 0;

            //when window re-sized keep the popup window to center
            $(window).resize(function () {
                //get window width
                var winW = $(window).width();

                //Set the popup window to center
                $(id).css('left', winW / 2 - $(id).width() / 2);

                //Get the screen height and width
                var maskHeight = $(document).height();
                var maskWidth = $(window).width();

                //Set heigth and width to mask to fill up the whole screen
                $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
            });
        }

        if (itr != 0 && !$("#ctl00_FramePopUp1").is(":visible")) {
            //e.preventDefault();
            $('#mask').hide();
            $('.window').hide();
        }

        $('.window #close').click(function () {
            if (url.indexOf("AdjustBucketValue_Popup.aspx") > -1) {
                location.reload();
            }
            $('.window').find('.popup-content-page-issuePage').removeClass('popup-content-page-issuePage');
            $('.window').removeClass('windowdisassociated');
            $('.window').removeClass('window-issuePage-bclc');
            $('.window').removeClass('tiermatchDialog');

            //Clear All Sessions
            $.ajax({
                type: "POST",
                url: "AjaxUtility.aspx/ResetSessions",
                data: "{}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {
                    if (headerName == "DAP Status") {
                        parent.IdPlayerDetails.click();
                    }
                    // Do something interesting here.
                }
            });
            $('#mask').hide();
            $('.window').hide();
        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });
    }
}

function launchBalanceTransferWindow(id, url, headerName, PlayerId) {
    if (itr == 0) {
        PlayerId1 = PlayerId;
        id1 = id;
        url1 = url;
        headerName1 = headerName;
        if (PlayerId != 0) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(500);
            $('#mask').fadeTo("slow", 0.5);

            LoadBalanceTransferPopup_Url(url + '&PlayerId=' + PlayerId, headerName);

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('top', (winH + 180) / 2 - $(id).height());
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //transition effect
            $(id).fadeIn(1000);
            itr = 0;

            //when window re-sized keep the popup window to center
            $(window).resize(function () {
                //get window width
                var winW = $(window).width();

                //Set the popup window to center
                $(id).css('left', winW / 2 - $(id).width() / 2);

                //Get the screen height and width
                var maskHeight = $(document).height();
                var maskWidth = $(window).width();

                //Set heigth and width to mask to fill up the whole screen
                $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
            });
        }

        if (itr != 0 && !$("#ctl00_FramePopUp6").is(":visible")) {
            //e.preventDefault();
            $('#mask').hide();
            $('.window').hide();
        }

        $('.window #close').click(function () {
            $('.window').find('.popup-content-page-issuePage').removeClass('popup-content-page-issuePage');
            $('.window').removeClass('windowdisassociated');
            $('.window').removeClass('window-issuePage-bclc');

            //Clear All Sessions
            $.ajax({
                type: "POST",
                url: "AjaxUtility.aspx/ResetSessions",
                data: "{}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {
                    if (headerName == "DAP Status") {
                        parent.IdPlayerDetails.click();
                    }
                    // Do something interesting here.
                }
            });
            $('#mask').hide();
            $('.window').hide();
        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });
    }
}

function launchDialogBox(id, url, headerName, PlayerId) {
    if (itr == 0) {
        document.getElementById('ctl00_dlgIFrame').src = "about:blank";
        PlayerId1 = PlayerId;
        id1 = id;
        url1 = url;
        headerName1 = headerName;
        if (PlayerId != 0) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(1000);
            $('#mask').fadeTo("slow", 0.5);

            LoadDialog_Url(url + '&PlayerId=' + PlayerId, headerName);

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('top', (winH + 180) / 2 - $(id).height());
            $(id).css('left', winW / 2 - $(id).width() / 2);

            $(id + ' .dialog-content-page').removeClass('popup-content-page-disassociated');
            $(id).removeClass('windowdisassociated');

            //transition effect
            $(id).fadeIn(2000);
            itr = 0;

            //when window re-sized keep the popup window to center
            $(window).resize(function () {
                //get window width
                var winW = $(window).width();

                //Set the popup window to center
                $(id).css('left', winW / 2 - $(id).width() / 2);

                //Get the screen height and width
                var maskHeight = $(document).height();
                var maskWidth = $(window).width();

                //Set heigth and width to mask to fill up the whole screen
                $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
            });
        }

        if (itr != 0 && !$("#ctl00_dlgIFrame").is(":visible")) {
            document.getElementById('ctl00_dlgIFrame').src = "about:blank";
            //e.preventDefault();
            $('#mask').hide();
            $('.dialog').hide();
        }

        $('.dialog #close').click(function () {
            //Clear All Sessions
            document.getElementById('ctl00_dlgIFrame').src = "about:blank";
            $.ajax({
                type: "POST",
                url: "AjaxUtility.aspx/ResetSessions",
                data: "{}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {
                    // Do something interesting here.
                }
            });
            $('#mask').hide();
            $('.dialog').hide();
        });

        $('.dialog #button').click(function () {
            $('#mask').hide();
            $('.dialog').hide();
        });
    }
}

function CloseDialogBox() {
    document.getElementById('ctl00_dlgIFrame').src = "about:blank"
    $('#mask').hide();
    $('.dialog').hide();
}

function CloseDialog1() {
    document.getElementById('ctl00_FramePopUp1').src = "about:blank"
    $('#mask').hide();
    $('.window').hide();
}






function doHourglass() {
    document.body.style.cursor = 'wait';
}

function setBG(gridId) {
    var id = "#" + gridId;
    var css = $('#btnDap').attr("class");
    if (css != null && css == "bgRow")
        $(id).addClass("norRow").removeClass("bgRow");
    else if (css != null && css == "norRow")
        $(id).addClass("bgRow").removeClass("norRow");
    setTimeout("setBG('" + gridId + "')", 1000); //1000 is equal to one second and call function every one second.
}

var id1, url1, headerName1, PlayerId1;
var itr = 0;
function launchWindow1(id, url, headerName, PlayerId) {
    $('#head2').css("overflow", "hidden");
    if (itr == 0) {
        PlayerId1 = PlayerId;
        id1 = id;
        url1 = url;
        headerName1 = headerName;
        if (PlayerId != 0) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(1000);
            $('#mask').fadeTo("slow", 0.5);

            // call the popup inside the iframe
            document.getElementById('ctl00_FramePopUp3').src = "";
            document.getElementById('ctl00_FramePopUp3').src = url + '&PlayerId=' + PlayerId;
            document.getElementById("popupheader3").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('top', (winH + 180) / 2 - $(id).height());
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //transition effect
            $(id).fadeIn(2000);
            itr = 0;
        }
        if (itr != 0 && !$("#ctl00_FramePopUp3").is(":visible")) {
            $('#mask').hide();
            $('.window3').hide();
        }
        $('.window3 #close').click(function () {
            $('#head2').css("overflow-y", "scroll");
            $('#mask').hide();
            $('.window3').hide();
            $('FramePopUp3').attr("src", '');
            var exclusion = headerName.indexOf("Exclusions");
            if (exclusion > -1) {
                parent.IdPlayerDetails.click();
            }
        });

        $('.window3 #button').click(function () {
            $('#mask').hide();
            $('.window3').hide();
        });

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }
}

function launchHostDialog(id, url, headerName, PlayerId) {
    if (itr == 0) {
        PlayerId1 = PlayerId;
        id1 = id;
        url1 = url;
        headerName1 = headerName;
        if (PlayerId != 0) {
            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            $('#mask').fadeIn(1000);
            $('#mask').fadeTo("slow", 0.5);

            // call the popup inside the iframe
            document.getElementById('ifrmHostsDetails').src = "";
            document.getElementById('ifrmHostsDetails').src = url + '&PlayerId=' + PlayerId;
            document.getElementById("popupheader4").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('top', (winH + 180) / 2 - $(id).height());
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //transition effect
            $(id).fadeIn(2000);
            itr = 0;
        }

        if (itr != 0 && !$("#ifrmHostsDetails").is(":visible")) {
            //e.preventDefault();
            $('#mask').hide();
            $('.windowHostDialog').hide();
        }

        $('.windowHostDialog #close').click(function () {
            $('#mask').hide();
            $('.windowHostDialog').hide();
            $('#ifrmHostsDetails').attr("src", '');
        });

        $('.windowHostDialog #button').click(function () {
            $('#mask').hide();
            $('.windowHostDialog').hide();
        });

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }
}

function LoadBalanceTransferPopup_Url(url, headerName) {
if (url == 'BalanceTransfer/BalanceInformationProgress.aspx?Child=0&PlayerId=1') {
        document.getElementById('ctl00_FramePopUp8').src = "";
        document.getElementById('ctl00_FramePopUp8').src = url;
    }
    else {
        document.getElementById('ctl00_FramePopUp6').src = "";
        document.getElementById('ctl00_FramePopUp6').src = url;
    }
    var isProgressPage = false;
    if (url.indexOf('BalanceTransferProgress') !== -1 || url.indexOf('BalanceInformationProgress') !== -1) {
    	isProgressPage = true;
    }

    if (url == 'BalanceTransfer/BalanceInformationProgress.aspx?Child=0&PlayerId=1') {
        document.getElementById("popupheader7").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' onclick='CloseBalanceTransferPopup(" + isProgressPage + ");' class='close-link'>Close</a>";
    }
    else {
        document.getElementById("popupheader6").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' onclick='CloseBalanceTransferPopup(" + isProgressPage + ");' class='close-link'>Close</a>";
    }
}

function LoadPopup_Url(url, headerName) {
    document.getElementById('ctl00_FramePopUp1').src = "";
    document.getElementById('ctl00_FramePopUp1').src = url;
    document.getElementById("popupheader").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";
}

function LoadDialog_Url(url, headerName) {
    document.getElementById('ctl00_dlgIFrame').src = "";
    document.getElementById('ctl00_dlgIFrame').src = url;
    document.getElementById("dialogHeader").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";
}

function PopUpCancel() {
    document.getElementById("mask").style.display = "none";
    document.getElementById("dialog2").style.display = "none";
}

function PopUpCancelManageList() {
    document.getElementById("mask").style.display = "none";
    document.getElementById("dialogManageList").style.display = "none";
}

//script for timer -logout user after inactivity or expiration,alert- confirmation from user enabled
var remainderTimer;
var expiretimer;

function ExtendTime(wer) {
    document.getElementById('ctl00_hdnReset').value = 3;
    document.getElementById('Timermodaldialog').style.display = 'none';
    var minExpTime = document.getElementById('ctl00_hidnTimeOutPeriod').value;
    var miliExpTime = wer * 60 * 1000;

    setInterval("alertIdeal3()", 1000);
    setInterval("alertIdeal()", (miliExpTime - 10000));
    setInterval("alertIdeal2()", (miliExpTime));
}

function alertIdeal3() {
    //Reseting Timer
    document.getElementById('ctl00_hdnReset').value = 1;
}

function IdlePageExpire(Id) {
    var minExpTime = document.getElementById(Id).value;
    var miliExpTime = minExpTime * 60 * 1000;

    setInterval("alertIdeal()", (miliExpTime - 10000));
    setInterval("alertIdeal2()", (miliExpTime));
}

function alertIdeal() {
    alert("10 Sec Remaining: " + document.getElementById('ctl00_hdnReset').value);
    if (document.getElementById('ctl00_hdnReset').value == "1") {
        document.getElementById('ctl00_hdnReset').value = 0;
        document.getElementById('Timermodaldialog').style.display = 'block';
    }
}

function alertIdeal2() {
    if (document.getElementById('ctl00_hdnReset').value == "0") {
        document.getElementById('ctl00_lnkLogout').click();
    }
}

function unloadPage() {
    clearTimeout(expiretimer);
    document.getElementById('ctl00_lnkLogout').click();
}

function doUnload() {
    if (window.screenTop < 0) {
        document.getElementById('ctl00_lnkLogout').click();
    }
    else if (window.event.clientX > 0 && window.event.clientY < 0) {
        document.getElementById('ctl00_lnkLogout').click();
    }
}

function Item_Click() {
    doTimer('ctl00_hidnTimeOutPeriod');
}

function doTimer(TimeOutVal) {
    clearInterval(countInterval);
    document.getElementById("ctl00_hidnWaitPeriod").value = document.getElementById("ctl00_hidAssignWaitPeriod").value;

    document.getElementById('Timermodaldialog').style.display = 'none';
    var minExpTime = document.getElementById(TimeOutVal).value;
    var miliExpTime = minExpTime * 60 * 1000;
    var waitPeriod = document.getElementById("ctl00_hidnWaitPeriod").value;
    var milliwaitPeriod = waitPeriod * 1000;

    clearTimeout(remainderTimer);
    clearTimeout(expiretimer);
    remainderTimer = setTimeout("ShowRemider()", miliExpTime - milliwaitPeriod);
    $.ajax({
        type: "POST",
        url: "AjaxUtility.aspx/RestoreServerSession",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            // Do something interesting here.
        }
    });
}

function CallTimerForMerge(TimeOutVal) {
    document.getElementById('Timermodaldialog').style.display = 'none';
    var minExpTime = TimeOutVal;
    var miliExpTime = minExpTime * 60 * 1000;
    var waitPeriod = document.getElementById("ctl00_hidnWaitPeriod").value;

    var milliwaitPeriod = waitPeriod * 1000;
    clearTimeout(remainderTimer);
    clearTimeout(expiretimer);
    remainderTimer = setTimeout("ShowRemider()", miliExpTime - milliwaitPeriod);
}

function ShowRemider() {
    document.getElementById("ctl00_hidAssignWaitPeriod").value = document.getElementById("ctl00_hidnWaitPeriod").value;
    document.getElementById('messageareaTimeOut').innerHTML = '<br /> Your Session will expire in ' + document.getElementById("ctl00_hidnWaitPeriod").value + ' seconds! Do you wish to continue?'
    document.getElementById('Timermodaldialog').style.display = 'block';
    clearTimeout(remainderTimer);
    countInterval = setInterval("downWaitPeriod()", 1000);
    //var waitPeriod = document.getElementById("ctl00_hidnWaitPeriod").value;
    //var milliwaitPeriod = waitPeriod * 1000;
    //expiretimer = setTimeout("unloadPage()", milliwaitPeriod);
}

function downWaitPeriod() {
    var waitPeriod = document.getElementById("ctl00_hidnWaitPeriod").value;
    var milliwaitPeriod = waitPeriod * 1000 - 1000;
    var assignWaitPeriod = milliwaitPeriod / 1000;
    if (assignWaitPeriod < 10)
        assignWaitPeriod = assignWaitPeriod;
    document.getElementById("ctl00_hidnWaitPeriod").value = assignWaitPeriod;
    document.getElementById('messageareaTimeOut').innerHTML = '<br />Your Session will expire in ' + document.getElementById("ctl00_hidnWaitPeriod").value + ' seconds! Do you wish to </br> continue?'
    if (assignWaitPeriod == 0) {
        clearInterval(countInterval);
        document.getElementById("ctl00_hidnWaitPeriod").value = document.getElementById("ctl00_hidAssignWaitPeriod").value;
        unloadPage();
    }
}

$(document).ready(function () {
    document.getElementById("ctl00_hidAssignWaitPeriod").value = document.getElementById("ctl00_hidnWaitPeriod").value;
});

//If the user interacts with any menu item which would navigate the user away from the earning rules controls, 
//while any selections have been made for a rule in progress, display a popup saying, 
//"Navigating away from this panel will abandon all current rule selections. Proceed?"
function ERconfirmExit() {
    if (document.getElementById('ctl00_hdnEarningRuleProgress').value == "1") {
        var msg = "Navigating away from this panel will abandon all current rule selections. Proceed?";
        var title = "";
        PumaConfirmExit(msg, title);
    }
}

function ExitConfirmed() {
    document.getElementById('ctl00_hdnButton').click();
    document.getElementById('dvERAlert').style.display = 'none';
}

function ExitNotConfirmed() {
    document.getElementById('ctl00_hdnEarningRuleProgress').value = "2";
    document.getElementById('dvERAlert').style.display = 'none';
    location.href = 'EarningRulesBuckets.aspx';
}

function AskConfirmation1(event) {
    event.stopPropagation();
    if (document.getElementById('ctl00_CalendarViewmaster').style.display == 'block') {
        document.getElementById('ctl00_CalendarViewmaster').style.display = 'none';
    }
    else {
        document.getElementById('ctl00_CalendarViewmaster').style.display = 'block';
    }
}

function set_str_date1(sender, args) {
    var vardate = new String(args.get_dates()[0]);
    var Dt = args.get_dates()[0];
    document.getElementById('ctl00_txtdob').focus();
    document.getElementById('ctl00_txtdob').value = Dt.format("MM/dd/yyyy");
    document.getElementById('ctl00_CalendarViewmaster').style.display = 'none';
}

function ExitERConfirmed() {
    document.getElementById('ctl00_ContentPlaceHolder1_webTabEarningRules_tmpl0_lnkDel').click();
    document.getElementById('dvERDelete').style.display = 'none';
}

function ExitERNotConfirmed() {
    document.getElementById('dvERDelete').style.display = 'none';
}






/*
*       Puma functions
*/

var itr1 = 0;
function PumaMessage(msg, title) {
    document.getElementById("ctl00_msg1").value = msg;
    document.getElementById("ctl00_title1").value = title;
    if (itr1 == 0) {

        var id = '#dialog2';
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(500);
        $('#mask').fadeTo("slow", 0.5);

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', winH / 2 - $(id).height());
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr1 = 0;
        var dvtitle = document.getElementById("popupheader2");

        var dvmsg = document.getElementById("dvpopupmsg1");

        dvmsg.innerHTML = msg;
        dvtitle.innerHTML = title;

        $('.window #close').click(function () {
            $('#mask').hide();
            $('.window').hide();

        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }
}

function PumaMessage(msg, title, nheight, nwidth) {
    document.getElementById("ctl00_msg1").value = msg;
    document.getElementById("ctl00_title1").value = title;
    if (itr1 == 0) {

        var id = '#dialog2';
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();
        $(id).width(nwidth);
        $(id).height(nheight);

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(500);
        $('#mask').fadeTo("slow", 0.5);

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', winH / 2 - $(id).height());
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr1 = 0;
        var dvtitle = document.getElementById("popupheader2");

        var dvmsg = document.getElementById("dvpopupmsg1");

        dvmsg.innerHTML = msg;
        dvtitle.innerHTML = title;

        $('.window #close').click(function () {
            $('#mask').hide();
            $('.window').hide();

        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }
}

function PumaMessageForManageList(msg, title) {
    document.getElementById("ctl00_msg1").value = msg;
    document.getElementById("ctl00_title1").value = title;
    if (itr1 == 0) {

        var id = '#dialogManageList';
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(500);
        $('#mask').fadeTo("slow", 0.5);

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', winH / 2 - $(id).height());
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr1 = 0;

        var dvtitle = document.getElementById("popupheaderManageList");
        var dvmsg = document.getElementById("dvpopupmsgManageList");

        dvmsg.innerHTML = msg;
        dvtitle.innerHTML = title;

        $('.window #close').click(function () {
            $('#mask').hide();
            $('.window').hide();

        });

        $('.window #button').click(function () {
            $('#mask').hide();
            $('.window').hide();
        });

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }
}

function PumaConfirmExit(msg, title) {
    var dvtitle = document.getElementById("dvERAlertHeader");
    var ele = document.getElementById("dvERAlert");
    var dvmsg = document.getElementById("dvERAlertMsg");
    ele.style.display = "block";
    dvmsg.innerHTML = msg;
    dvtitle.innerHTML = title;
}

function PumaERDelMessage(msg, title) {
    var dvtitle = document.getElementById("dvERDelHeader");
    var ele = document.getElementById("dvERDelete");
    var dvmsg = document.getElementById("dvERDeleteMsg");
    ele.style.display = "block";
    dvmsg.innerHTML = msg;
    dvtitle.innerHTML = title;
}

function EditEnrollPlayer(event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
    event.preventDefault();
    if (typeof EditPlayer != 'undefined')
        EditPlayer();
}
function toDate(input, year, ID) {
    var str = input.value;
    if (str.length == 8) {
        var yy = str.substr(6, 2);
        var newdate = (yy < year) ? '20' + yy : '19' + yy;
        input.value = str.substr(0, 2) + '/' + str.substr(3, 2) + '/' + newdate; //1990-01-25
    }
    if (str.length != 0) {
        ValidateForm(input, ID);
    }
    else {
        $("#" + ID).text("");
    }
}

function pageLoad() {
    $(document).ready(function () {
        $('#ctl00_txtdob.ClientID').blur(function () { toDate(document.getElementById("ctl00_txtdob.ClientID"), 30, 'MessagetxtDateofBirth'); });
        $('.calendar.igmc_Control').click(function (evt) {
            evt.stopPropagation();
        })
        $(document).click(function () {
            $('.calendar.igmc_Control').css("display", 'none');
            $('.calendar.igmc_Control').click(function (evt) {
                evt.stopPropagation();
            })
        });
    });
}
//$(document).delegate('.dateFormatExt', 'blur', function (e) {
//    $('#ctl00_txtdob.ClientID').blur(function () { toDate(document.getElementById("ctl00_txtdob.ClientID"), 30); });
//});
$(document).delegate('.dateFormatExt', 'keydown', function (e) {
    // Allow: backspace, delete, tab, escape, enter and .
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
        // Allow: Ctrl+A, Command+A
        (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
        // Allow: home, end, left, right, down, up
        (e.keyCode >= 35 && e.keyCode <= 40)) {
        // let it happen, don't do anything
        return;
    }
    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
        e.preventDefault();
    }
    if (e.keyCode === 47) {
        return false;
    }
});

$(document).delegate('.dateFormatExt', 'keyup', function (e) {
    if (e.which === 8 || e.which === 127) {
    } else if (this.value.length === 2 || this.value.length === 5) {
        this.value += "/";
    }
});

function CloseBalanceTransferPopup() {
    parent.FramePopUp1.src = "about:blank";
    parent.dialog1.style.display = 'None';
    parent.FramePopUp6.src = "about:blank";
    parent.dialog4.style.display = 'None';
    parent.FramePopUp8.src = "about:blank";
    parent.dialog6.style.display = 'None';
    parent.mask.style.display = 'None';
}

function RedirectToEmployeeDashboard() {
    if (window.location.href.indexOf("EmployeeDashboard.aspx") > -1) {
        return false;
    }

    window.location.href = "EmployeeDashboard.aspx";
    return false;
}

function expandSearchClick(toExpand) {
    if (toExpand) {
        $("#ctl00_lnkSearchSVG").hide();
        $("#ctl00_lnkSearchCloseSVG").show();
        $(".search-panel").show();
        $(".tip-search-panel").show();
        $(".searchTabs").show();

        $("#ctl00_btnEventsOfferSearch").removeClass("searchTabBtnSelected");
        $("#ctl00_btnPatronSearch").addClass("searchTabBtnSelected");
        $("#ctl00_txtPlayerId").focus();
    }
    else {
        $("#ctl00_lnkSearchCloseSVG").hide();
        $("#ctl00_lnkSearchSVG").show();
        $(".search-panel").hide();
        $(".tip-search-panel").hide();
        $(".searchTabs").hide();
    }

    $(".eventsAndOffers-search-panel").hide();
    return false;
}
function CloseBalanceTransferPopup(isProgress) {
	if (isProgress) {
		document.getElementById('ctl00_FramePopUp6').contentWindow.CloseBalanceTransfer();
	}
	else {
		parent.FramePopUp1.src = "about:blank";
		parent.dialog1.style.display = 'None';
		parent.FramePopUp6.src = "about:blank";
		parent.dialog4.style.display = 'None';
		parent.FramePopUp8.src = "about:blank";
		parent.dialog6.style.display = 'None';
		parent.mask.style.display = 'None';
	}
}

function launchWindowEnhancedComments(id, url, headerName, PlayerId) {
    $('#head2').css("overflow", "hidden");
    if (PlayerId != 0) {
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(1000);
        $('#mask').fadeTo("slow", 0.5);

        // call the popup inside the iframe
        document.getElementById('ctl00_FramePopUp7').src = "";
        document.getElementById('ctl00_FramePopUp7').src = url + '&PlayerId=' + PlayerId;
        document.getElementById("popupheaderEnhancedComments").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', 0);
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr = 0;

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }

    $('.windowEnhancedComments #close').click(function () {
        $('#head2').css("overflow-y", "scroll");
        $('#mask').hide();
        $('.windowEnhancedComments').hide();
        $('FramePopUp7').attr("src", '');
    });

    $('.windowEnhancedComments #button').click(function () {
        $('#mask').hide();
        $('.windowEnhancedComments').hide();
    });
}

function launchWindowConsentPopup(id, url, headerName, PlayerId) {
    $('#head2').css("overflow", "hidden");
    if (PlayerId != 0) {
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(1000);
        $('#mask').fadeTo("slow", 0.5);

        // call the popup inside the iframe
        document.getElementById('ctl00_FrameConsentPopup').src = "";
        document.getElementById('ctl00_FrameConsentPopup').src = url + '&PlayerId=' + PlayerId;
        document.getElementById("popupheaderConsent").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', 0);
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr = 0;

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }

    $('.windowConsent #close').click(function () {
        $('#head2').css("overflow-y", "scroll");
        $('#mask').hide();
        $('.windowConsent').hide();
        $('FrameConsentPopup').attr("src", '');
    });

    $('.windowConsent #button').click(function () {
        $('#mask').hide();
        $('.windowConsent').hide();
    });
}

function launchWindowAccountUpdatePopup(id, url, headerName, PlayerId) {
    $('#head2').css("overflow", "hidden");
    if (PlayerId != 0) {
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(1000);
        $('#mask').fadeTo("slow", 0.5);

        // call the popup inside the iframe
        document.getElementById('ctl00_AccountFrame').src = "";
        document.getElementById('ctl00_AccountFrame').src = url + '&PlayerId=' + PlayerId;
        document.getElementById("popupheaderAccount").innerHTML = "<span id='hd'>" + headerName + "</span><a id='close' title='Close' tabindex='' class='close-link hand'>Close</a>";

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', 0);
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr = 0;

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }

    $('.windowAccountUpdate #close').click(function () {
        $('#head2').css("overflow-y", "scroll");
        $('#mask').hide();
        $('.windowAccountUpdate').hide();
        $('AccountFrame').attr("src", '');
    });

    $('.windowAccountUpdate #button').click(function () {
        $('#mask').hide();
        $('.windowAccountUpdate').hide();
    });
}
function launchManualLOBAdjustment(id, url, headerName, PlayerId) {

    if (PlayerId != 0) {
        //Get the screen height and width
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //Set heigth and width to mask to fill up the whole screen
        $('#mask').css({ 'width': maskWidth, 'height': maskHeight });

        //transition effect		
        $('#mask').fadeIn(1000);
        $('#mask').fadeTo("slow", 0.5);

        // call the popup inside the iframe
        document.getElementById('ctl00_FramePopupLOB').src = "";
        document.getElementById('ctl00_FramePopupLOB').src = url;
        document.getElementById("popupheaderLaunchManualLOBAdjustment").innerHTML = "<span id='hd'>" + "MANUAL LINE OF BUSINESS ADJUSTMENT" + "</span><a id='close' title='Close' tabindex='' class='close-link'>Close</a>";

        //Get the window height and width
        var winH = $(window).height();
        var winW = $(window).width();

        //Set the popup window to center
        $(id).css('top', 0);
        $(id).css('left', winW / 2 - $(id).width() / 2);

        //transition effect
        $(id).fadeIn(2000);
        itr = 0;

        //when window re-sized keep the popup window to center
        $(window).resize(function () {
            //get window width
            var winW = $(window).width();

            //Set the popup window to center
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //Get the screen height and width
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask').css({ 'width': maskWidth, 'height': maskHeight });
        });
    }

    $('.windowLaunchManualLOBAdjustment #close').click(function () {
        $('#mask').hide();
        $('.windowLaunchManualLOBAdjustment').hide();
        $('FramePopupLOB').attr("src", '');
    });

    $('.windowLaunchManualLOBAdjustment #button').click(function () {
        $('#mask').hide();
        $('.windowLaunchManualLOBAdjustment').hide();
    });
}

/*   EventsOffer Search Functions   */
function searchTabBtnClick(e) {

    if (e.target.id.indexOf("btnPatronSearch") > -1) {
        $("#ctl00_btnEventsOfferSearch").removeClass("searchTabBtnSelected");
        $("#ctl00_btnPatronSearch").addClass("searchTabBtnSelected");
        $(".search-panel").show();
        $(".eventsAndOffers-search-panel").hide();
        $("#ctl00_txtPlayerId").focus();
    }
    else {
        $("#ctl00_btnPatronSearch").removeClass("searchTabBtnSelected");
        $("#ctl00_btnEventsOfferSearch").addClass("searchTabBtnSelected");
        $(".search-panel").hide();
        $(".eventsAndOffers-search-panel").show();
    }

    return false;
}

function AskConfirmationEventsOffer(isStartDate,event) {
    event.stopPropagation();
    if (isStartDate) {
        if (document.getElementById('ctl00_EventsOfferCalendarViewmaster_StartDate').style.display == 'block') {
            document.getElementById('ctl00_EventsOfferCalendarViewmaster_StartDate').style.display = 'none';
        }
        else {
            document.getElementById('ctl00_EventsOfferCalendarViewmaster_StartDate').style.display = 'block';
        }
    }
    else {
        if (document.getElementById('ctl00_EventsOfferCalendarViewmaster_EndDate').style.display == 'block') {
            document.getElementById('ctl00_EventsOfferCalendarViewmaster_EndDate').style.display = 'none';
        }
        else {
            document.getElementById('ctl00_EventsOfferCalendarViewmaster_EndDate').style.display = 'block';
        }
    }
}

function set_start_date_EventsOffer(sender, args) {
    var Dt = args.get_dates()[0];
    document.getElementById('ctl00_txtEventsOfferStartDate').focus();
    document.getElementById('ctl00_txtEventsOfferStartDate').value = Dt.format("MM/dd/yyyy");
    document.getElementById('ctl00_EventsOfferCalendarViewmaster_StartDate').style.display = 'none';
    document.getElementById('ctl00_EventsOfferCalendarViewmaster_EndDate').style.display = 'none';
}

function set_end_date_EventsOffer(sender, args) {
    var Dt = args.get_dates()[0];
    document.getElementById('ctl00_txtEventsOfferEndDate').focus();
    document.getElementById('ctl00_txtEventsOfferEndDate').value = Dt.format("MM/dd/yyyy");
    document.getElementById('ctl00_EventsOfferCalendarViewmaster_StartDate').style.display = 'none';
    document.getElementById('ctl00_EventsOfferCalendarViewmaster_EndDate').style.display = 'none';
}

function ValidateEventsOfferSearch(e) {

    e.stopPropagation();
    e.stopImmediatePropagation();

    var hidAllowEventsOfferSearch = document.getElementById("ctl00_hidAllowEventsOfferSearch");
    if (hidAllowEventsOfferSearch.value != "1") {
        PumaMessage("You do not have Events & Offer search permission!", "");
        return false;
    }

    //user has permission
    var returnVal = false;
    var queryStr = "";

    var txtStartDate = $("#ctl00_txtEventsOfferStartDate").val().trim();
    var txtEndDate = $("#ctl00_txtEventsOfferEndDate").val().trim();
    var startDate = new Date(txtStartDate);
    var endDate = new Date(txtEndDate);

    if (txtStartDate != "" && txtStartDate.toLowerCase() != "mm/dd/yyyy" && txtEndDate != "" && txtEndDate.toLowerCase() != "mm/dd/yyyy" && startDate > endDate) {
        PumaMessage("Please enter a valid To date");
        return false;
    }

    if (txtStartDate != "" && txtStartDate.toLowerCase() != "mm/dd/yyyy") {
        queryStr += 'FromDate=' + txtStartDate;
        returnVal = true;
    }

    if (txtEndDate != "" && txtEndDate.toLowerCase() != "mm/dd/yyyy") {
        queryStr += '&EndDate=' + txtEndDate;
        returnVal = true;
    }

    if ($("#ctl00_txtEventsOfferName").val().trim() != '' && $("#ctl00_txtEventsOfferName").val().trim() != 'Events & Offer Name') {
        queryStr += '&EventsOfferName=' + $("#ctl00_txtEventsOfferName").val().trim();
        returnVal = true;
    }

    if ($("#ctl00_ddlEventsOfferType").val() != '0') {
        queryStr += '&TypeID=' + $("#ctl00_ddlEventsOfferType").val();
        returnVal = true;
    }

    if ($("#ctl00_ddlEventsOfferProperty").val() != '0') {
        queryStr += '&PropertyID=' + $("#ctl00_ddlEventsOfferProperty").val();
        returnVal = true;
    }

    if ($("#ctl00_ddlEventsOfferState").val() != '0') {
        queryStr += '&StateID=' + $("#ctl00_ddlEventsOfferState").val();
        returnVal = true;
    }

    if ($("#ctl00_ddlEventsOfferStatus").val() != '4') {
        queryStr += '&StatusID=' + $("#ctl00_ddlEventsOfferStatus").val();
        returnVal = true;
    }

    if (returnVal) {

        var url = 'EventsOffers.aspx?' + queryStr;
        window.location.href = url;
    }

    return false;
}

$(document).on("keydown", ".eventsAndOffers-search-panel input[type=text]", function (e) {
    if (e.keyCode === 13) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        $("#ctl00_searchEventsOffer").click();

        return false;
    }
})
/*   EventsOffer Search Functions   */
/*   EventsOffer Search Functions   */