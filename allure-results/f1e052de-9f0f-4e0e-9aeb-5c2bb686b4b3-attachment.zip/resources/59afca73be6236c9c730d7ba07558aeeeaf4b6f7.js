//var Iteration = 0;
function loadXMLDoc(url, txtObj, divObj, btnObj) {
    var xmlhttp;
    var Iteration;
    Iteration = Math.floor(Math.random() * 10000);
    url = url + '&Iteration=' + Iteration;
    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
        //alert(url);
    }
    else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        //alert(url);
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            if (txtObj != '') {
                document.getElementById(txtObj).value = xmlhttp.responseText;
                document.getElementById(btnObj).click();
            }
            else if (divObj != '') {
                //alert('Iteration : ' + Iteration);  
                try {
                    document.getElementById(divObj).innerHTML = xmlhttp.responseText;
                }
                catch (e) {
                    window.history.forward(1);
                    window.location.href = "SessionOut.aspx";
                }
                //alert(xmlhttp.responseText);
            }
        }
    }
    //alert(txtObj);
    // alert("xmlhttp" + xmlhttp + " :: "+url);
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getRecordCount(obj, RecordType, MasterId) {
    var url = "AjaxUtilityGroupSeed.aspx?RecordType=" + RecordType + "&MasterID=" + MasterId;
    var txtObj = obj;
    //alert("calling....."+txtObj + "  Url: "+url);
    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        //alert("Ready State Changed");
        //alert("xmlhttp.readyState :" + xmlhttp.readyState);
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            if (txtObj != '') {
                document.getElementById(txtObj).value = xmlhttp.responseText;
                // document.getElementById(btnObj).click();
                // alert("Page Call Success");
            }
            else if (divObj != '') {
                document.getElementById(divObj).innerHTML = xmlhttp.responseText;
            }
        }
    }
    //alert(txtObj);
    // alert("xmlhttp" + xmlhttp + " :: "+url);
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function loadXMLDocforMenu(url, txtObj, divObj, btnObj) {
    var xmlhttp;
    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            if (divObj != '') {
                document.getElementById(divObj).innerHTML = xmlhttp.responseText;
            }
        }
    }
    //alert(txtObj);
    // alert("xmlhttp" + xmlhttp + " :: "+url);
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
