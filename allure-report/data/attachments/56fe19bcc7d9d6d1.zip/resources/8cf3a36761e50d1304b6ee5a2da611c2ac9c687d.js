function onOutFocusSearchControl(Ctrl, defaultText) {
    //alert(document.getElementById(Ctrl).value);
    if (document.getElementById(Ctrl).value == "") {
        document.getElementById(Ctrl).value = defaultText;
    }
}

function onFocusSearchControl(Ctrl, defaultText) {
    //alert(Ctrl);
    if (document.getElementById(Ctrl).value == defaultText) {
        document.getElementById(Ctrl).value = "";
    }
}

function fncInputNumericValuesOnly() 
{
    if (!(event.keyCode == 45 || event.keyCode == 46 || event.keyCode == 48 || event.keyCode == 49 || event.keyCode == 50 || event.keyCode == 51 || event.keyCode == 52 || event.keyCode == 53 || event.keyCode == 54 || event.keyCode == 55 || event.keyCode == 56 || event.keyCode == 57)) 
{ event.returnValue = false; } }


function isDate(txtDate) 
{     
var objDate,  // date object initialized from the txtDate string         
mSeconds, // txtDate in milliseconds         
day,      // day         
month,    // month         
year;     // year     // date length should be 10 characters (no more no less)     
if (txtDate.length !== 10) 
{         
return false;     }     // third and sixth character should be '/'     
if (txtDate.substring(2, 3) !== '/' || txtDate.substring(5, 6) !== '/') 
{         return false;     }     
// extract month, day and year from the txtDate (expected format is mm/dd/yyyy)     
// subtraction will cast variables to integer implicitly (needed     
// for !== comparing)     
month = txtDate.substring(0, 2) - 1; // because months in JS start from 0     
day = txtDate.substring(3, 5) - 0;     
year = txtDate.substring(6, 10) - 0;     // test year range     
if (year < 1000 || year > 3000) 
{         return false;     }     
// convert txtDate to milliseconds     
mSeconds = (new Date(year, month, day)).getTime();     
// initialize Date() object from calculated milliseconds     
objDate = new Date();     
objDate.setTime(mSeconds);     
// compare input date and parts from Date() object     
// if difference exists then date isn't valid     
if (objDate.getFullYear() !== year ||         
    objDate.getMonth() !== month ||         
    objDate.getDate() !== day)
{ return false; }     // otherwise return true     
    return true; } 
